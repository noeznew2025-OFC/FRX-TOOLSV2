#!/system/bin/sh
# GRAFIK MINECRAFT BY FARUQ
# Device compatibility checker + ANGLE configuration helper
# Intended for Brevent Exec Command (shell), no interactive input.

VERSION="2.0"
BACKUP_DIR="/sdcard/Download/.faruq_angle_backup"
PROBE_KEY="faruq_angle_support_probe"

# ANSI colors
R='\033[0m'; B='\033[1m'; C='\033[36m'; G='\033[32m'; Y='\033[33m'; X='\033[31m'; M='\033[35m'; W='\033[37m'

line() { printf '%b\n' "${C}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${R}"; }
ok()   { printf '%b\n' "${G}[✓]${R} $*"; }
warn() { printf '%b\n' "${Y}[!]${R} $*"; }
fail() { printf '%b\n' "${X}[✗]${R} $*"; }
info() { printf '%b\n' "${W}[i]${R} $*"; }

get_sdk() { getprop ro.build.version.sdk 2>/dev/null; }
get_android() { getprop ro.build.version.release 2>/dev/null; }
get_device() { getprop ro.product.manufacturer 2>/dev/null; }
get_model() { getprop ro.product.model 2>/dev/null; }

show_header() {
    printf '%b\n' "${M}${B}"
    printf '%s\n' '  ██████╗ ██████╗  █████╗ ███████╗██╗██╗  ██╗'
    printf '%s\n' '  ██╔════╝ ██╔══██╗██╔══██╗██╔════╝██║██║ ██╔╝'
    printf '%s\n' '  ███████╗ ██████╔╝███████║█████╗  ██║█████╔╝ '
    printf '%s\n' '  ╚════██║ ██╔══██╗██╔══██║██╔══╝  ██║██╔═██╗ '
    printf '%s\n' '  ██████╔╝ ██║  ██║██║  ██║██║     ██║██║  ██╗'
    printf '%s\n' '  ╚═════╝  ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝  ╚═╝'
    printf '%b\n' "${R}${Y}             GRAFIK MINECRAFT BY FARUQ${R}"
    printf '%b\n' "${W}                    VERSION ${VERSION}${R}"
    line
}

check_device() {
    PASS=1
    printf '%b\n' "${B}${C}DEVICE INFORMATION${R}"
    printf 'Brand       : %s\n' "$(get_device)"
    printf 'Model       : %s\n' "$(get_model)"
    printf 'Android     : %s\n' "$(get_android)"
    printf 'SDK         : %s\n' "$(get_sdk)"
    printf 'Shell ID    : %s\n' "$(id 2>/dev/null)"
    line

    printf '%b\n' "${B}${C}COMPATIBILITY CHECK${R}"
    SDK="$(get_sdk)"
    case "$SDK" in
        ''|*[!0-9]*) fail "Versi Android/SDK tidak terbaca."; PASS=0 ;;
        *) if [ "$SDK" -ge 29 ] 2>/dev/null; then ok "Android 10 atau lebih baru (syarat dasar ANGLE)."; else fail "Android di bawah 10: dukungan ANGLE belum memenuhi syarat dasar."; PASS=0; fi ;;
    esac

    for CMD in settings getprop setprop pm; do
        if command -v "$CMD" >/dev/null 2>&1; then ok "Perintah $CMD tersedia."; else fail "Perintah $CMD tidak ditemukan."; PASS=0; fi
    done

    if settings get global angle_gl_driver_selection_pkgs >/dev/null 2>&1; then
        ok "Database Settings Global dapat dibaca."
    else
        fail "Settings Global tidak bisa dibaca."; PASS=0
    fi

    # Safe temporary write/read/delete test using a private test key.
    OLD_PROBE="$(settings get global "$PROBE_KEY" 2>/dev/null)"
    if settings put global "$PROBE_KEY" faruq_test >/dev/null 2>&1 && [ "$(settings get global "$PROBE_KEY" 2>/dev/null)" = "faruq_test" ]; then
        ok "Akses tulis Settings Global tersedia."
    else
        fail "Akses tulis Settings Global ditolak."; PASS=0
    fi
    if [ -n "$OLD_PROBE" ] && [ "$OLD_PROBE" != "null" ]; then
        settings put global "$PROBE_KEY" "$OLD_PROBE" >/dev/null 2>&1
    else
        settings delete global "$PROBE_KEY" >/dev/null 2>&1
    fi

    if [ -d /sdcard/Download ] && [ -w /sdcard/Download ]; then
        ok "Folder Download bisa ditulis untuk backup."
    else
        warn "Folder Download tidak bisa ditulis; fitur backup mungkin gagal."
    fi

    line
    if [ "$PASS" -eq 1 ]; then
        printf '%b\n' "${G}${B}DEVICE LOLOS PEMERIKSAAN DASAR${R}"
        warn "Ini belum menjamin ANGLE/efek grafis didukung oleh ROM atau game."
        printf '\n%b\n' "${B}PILIH CMD SESUAI GAME${R}"
        printf '%b\n' "Free Fire biasa : ${Y}sh /sdcard/Download/GrafikMcByFaruq.sh ff on smooth 2${R}"
        printf '%b\n' "Free Fire MAX   : ${Y}sh /sdcard/Download/GrafikMcByFaruq.sh max on smooth 2${R}"
        printf '\n%b\n' "Preset lain: pixel atau retro. LOD: 1 sampai 4."
        return 0
    else
        printf '%b\n' "${X}${B}DEVICE BELUM LOLOS PEMERIKSAAN${R}"
        warn "Jangan jalankan konfigurasi dulu. Periksa Android, Brevent, dan izin shell."
        return 1
    fi
}

get_game() {
    case "$1" in
        ff) GAME="Free Fire biasa"; PACKAGE="com.dts.freefireth" ;;
        max) GAME="Free Fire MAX"; PACKAGE="com.dts.freefiremax" ;;
        *) return 1 ;;
    esac
}

save_backup() {
    mkdir -p "$BACKUP_DIR" 2>/dev/null
    [ -d "$BACKUP_DIR" ] || return 1
    if [ ! -f "$BACKUP_DIR/old_pkgs" ]; then
        settings get global angle_gl_driver_selection_pkgs 2>/dev/null > "$BACKUP_DIR/old_pkgs"
        settings get global angle_gl_driver_selection_values 2>/dev/null > "$BACKUP_DIR/old_values"
        getprop debug.angle.feature_overrides_enabled 2>/dev/null > "$BACKUP_DIR/old_feature"
    fi
    return 0
}

restore_value() {
    KEY="$1"; FILE="$2"
    if [ -f "$FILE" ]; then
        VALUE="$(cat "$FILE" 2>/dev/null)"
        if [ -z "$VALUE" ] || [ "$VALUE" = "null" ]; then
            settings delete global "$KEY" >/dev/null 2>&1
        else
            settings put global "$KEY" "$VALUE" >/dev/null 2>&1
        fi
    fi
}

report() {
    line
    printf '%b\n' "${B}${C}HASIL KONFIGURASI${R}"
    printf 'Game       : %s\n' "$GAME"
    printf 'Package    : %s\n' "$PACKAGE"
    printf 'Preset     : %s\n' "$PRESET_NAME"
    printf 'LOD        : %s\n' "${LOD:-Tidak digunakan}"
    printf 'Status     : %b\n' "$STATUS_TEXT"
    printf 'ANGLE list : %s\n' "$(settings get global angle_gl_driver_selection_pkgs 2>/dev/null)"
    printf 'ANGLE mode : %s\n' "$(settings get global angle_gl_driver_selection_values 2>/dev/null)"
    printf 'Feature    : %s\n' "$(getprop debug.angle.feature_overrides_enabled 2>/dev/null)"
    line
    warn "Status aktif berarti nilai konfigurasi terbaca kembali, bukan bukti FPS naik atau game pasti memakai efeknya."
}

apply_config() {
    MODE="$1"; LOD="$2"
    case "$MODE" in
        smooth) PRESET_NAME="Smooth Graphics"; FEATURE="disableAnisotropicFiltering:forceTextureLodOffset${LOD}" ;;
        pixel)  PRESET_NAME="Pixel Graphics"; FEATURE="forceNearestFiltering:disableAnisotropicFiltering:forceTextureLodOffset${LOD}" ;;
        retro)  PRESET_NAME="Retro Graphics"; FEATURE="forceNearestFiltering:disableAnisotropicFiltering:forceTextureLodOffset${LOD}" ;;
        *) fail "Preset tidak dikenal. Gunakan smooth, pixel, atau retro."; return 1 ;;
    esac
    case "$LOD" in 1|2|3|4) ;; *) fail "LOD harus 1, 2, 3, atau 4."; return 1 ;; esac

    if ! check_device >/dev/null 2>&1; then
        fail "Pemeriksaan perangkat gagal. Jalankan script tanpa argumen untuk melihat detail."; return 1
    fi
    if ! pm path "$PACKAGE" 2>/dev/null | grep -q '^package:'; then
        fail "$GAME tidak terdeteksi. Pastikan game terpasang dan package name sesuai." 
        info "Jika memakai aplikasi hasil clone, package name bisa berbeda."
        return 1
    fi
    if ! save_backup; then fail "Tidak bisa membuat backup di $BACKUP_DIR"; return 1; fi

    settings put global angle_gl_driver_selection_pkgs "$PACKAGE" >/dev/null 2>&1
    settings put global angle_gl_driver_selection_values angle >/dev/null 2>&1
    setprop debug.angle.feature_overrides_enabled "$FEATURE" >/dev/null 2>&1
    am force-stop "$PACKAGE" >/dev/null 2>&1

    READ_PKGS="$(settings get global angle_gl_driver_selection_pkgs 2>/dev/null)"
    READ_MODE="$(settings get global angle_gl_driver_selection_values 2>/dev/null)"
    READ_FEATURE="$(getprop debug.angle.feature_overrides_enabled 2>/dev/null)"
    if [ "$READ_PKGS" = "$PACKAGE" ] && [ "$READ_MODE" = "angle" ]; then
        STATUS_TEXT="${G}KONFIGURASI TERSIMPAN${R}"
        if [ "$READ_FEATURE" != "$FEATURE" ]; then
            warn "Feature override tidak terbaca sama; sebagian fitur mungkin dibatasi ROM."
        fi
        report
        info "Buka kembali game secara manual agar Android memuat ulang pengaturan."
        return 0
    else
        STATUS_TEXT="${X}GAGAL / TIDAK TERSIMPAN${R}"
        report
        return 1
    fi
}

turn_off() {
    PRESET_NAME="Default / Off"; LOD="-"
    if [ -f "$BACKUP_DIR/old_pkgs" ]; then
        restore_value angle_gl_driver_selection_pkgs "$BACKUP_DIR/old_pkgs"
        restore_value angle_gl_driver_selection_values "$BACKUP_DIR/old_values"
        OLD_FEATURE="$(cat "$BACKUP_DIR/old_feature" 2>/dev/null)"
        if [ -n "$OLD_FEATURE" ]; then setprop debug.angle.feature_overrides_enabled "$OLD_FEATURE" >/dev/null 2>&1; else setprop debug.angle.feature_overrides_enabled "" >/dev/null 2>&1; fi
        STATUS_TEXT="${G}PENGATURAN SEBELUMNYA DIPULIHKAN${R}"
    else
        settings delete global angle_gl_driver_selection_pkgs >/dev/null 2>&1
        settings delete global angle_gl_driver_selection_values >/dev/null 2>&1
        setprop debug.angle.feature_overrides_enabled "" >/dev/null 2>&1
        STATUS_TEXT="${Y}PENGATURAN ANGLE DIHAPUS (TANPA BACKUP)${R}"
    fi
    am force-stop "$PACKAGE" >/dev/null 2>&1
    report
    info "Buka kembali game secara manual."
}

show_status() {
    PRESET_NAME="Status saat ini"; LOD="-"
    CURRENT="$(settings get global angle_gl_driver_selection_pkgs 2>/dev/null)"
    if [ "$CURRENT" = "$PACKAGE" ]; then STATUS_TEXT="${G}PACKAGE TERPILIH DI SETTINGS${R}"; else STATUS_TEXT="${Y}PACKAGE TIDAK TERPILIH${R}"; fi
    report
}

show_usage() {
    printf '%b\n' "${B}CARA PAKAI${R}"
    printf '%s\n' '1) Cek dukungan perangkat:'
    printf '%s\n' '   sh /sdcard/Download/GrafikMcByFaruq.sh'
    printf '%s\n' '2) Free Fire biasa:'
    printf '%s\n' '   sh /sdcard/Download/GrafikMcByFaruq.sh ff on pixel 2'
    printf '%s\n' '3) Free Fire MAX:'
    printf '%s\n' '   sh /sdcard/Download/GrafikMcByFaruq.sh max on smooth 2'
    printf '%s\n' '4) Matikan/pulihkan:'
    printf '%s\n' '   sh /sdcard/Download/GrafikMcByFaruq.sh ff off'
    printf '%s\n' '   sh /sdcard/Download/GrafikMcByFaruq.sh max off'
    printf '%s\n' '5) Cek status:'
    printf '%s\n' '   sh /sdcard/Download/GrafikMcByFaruq.sh ff status'
    printf '%s\n' '   sh /sdcard/Download/GrafikMcByFaruq.sh max status'
    printf '\n%s\n' 'Preset: smooth | pixel | retro     LOD: 1 | 2 | 3 | 4'
}

show_header
if [ "$#" -eq 0 ] || [ "$1" = "check" ]; then
    check_device
    exit $?
fi

if ! get_game "$1"; then
    fail "Pilih game: ff atau max."
    show_usage
    exit 1
fi
ACTION="$2"
case "$ACTION" in
    on)
        if [ "$#" -lt 4 ]; then fail "Format belum lengkap."; show_usage; exit 1; fi
        apply_config "$3" "$4"
        exit $?
        ;;
    off)
        turn_off
        ;;
    status)
        show_status
        ;;
    *)
        fail "CMD tidak dikenal: $ACTION"
        show_usage
        exit 1
        ;;
esac
