package com.frx.tools

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast

/** Transparent bridge: keeps the game visible while Android displays its required capture-consent dialog. */
class CapturePermissionActivity : Activity() {
    private val requestCode = 711
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        overridePendingTransition(0, 0)
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        try {
            startActivityForResult(manager.createScreenCaptureIntent(), requestCode)
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak bisa meminta izin screenshot: ${e.message}", Toast.LENGTH_LONG).show()
            restoreFloating(); finish()
        }
    }

    @Deprecated("MediaProjection consent callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != this.requestCode) return
        if (resultCode == RESULT_OK && data != null) {
            val serviceIntent = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT, resultCode)
                putExtra(CaptureService.EXTRA_DATA, data)
                putExtra(CaptureService.EXTRA_RESTORE_FLOATING, true)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
        } else {
            Toast.makeText(this, "Screenshot dibatalkan.", Toast.LENGTH_SHORT).show()
            restoreFloating()
        }
        finish()
        overridePendingTransition(0, 0)
    }

    private fun restoreFloating() {
        startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACTION_RESTORE))
    }
}
