package com.frx.tools

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    companion object { const val ACTION_SCREENSHOT = "com.frx.tools.REQUEST_SCREENSHOT" }
    private lateinit var logView: TextView
    private val screenshotRequest = 710
    private var selectedGame = "ff"
    private var selectedPreset = "smooth"
    private var selectedLod = 2
    private val handler = Handler(Looper.getMainLooper())
    private val bg = Color.rgb(8, 11, 18)
    private val panel = Color.rgb(17, 23, 34)
    private val red = Color.rgb(255, 55, 69)
    private val muted = Color.rgb(160, 172, 190)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        if (intent?.action == ACTION_SCREENSHOT) handler.postDelayed({ requestScreenshot() }, 250)
    }

    private var pageHost: LinearLayout? = null

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(18))
            setBackgroundColor(bg)
        }
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = gradient(intArrayOf(Color.rgb(25, 34, 50), Color.rgb(12, 16, 25)), dp(20))
        }
        hero.addView(ImageView(this).apply { setImageResource(R.drawable.frx_logo); scaleType = ImageView.ScaleType.FIT_CENTER }, LinearLayout.LayoutParams(dp(62), dp(62)))
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        brand.addView(label("FRX TOOLS", 24f, Color.WHITE, true))
        brand.addView(label("ROG GAMING UTILITY", 10f, red, true))
        brand.addView(label("DEVELOPER • FaruqExe", 10f, muted, false))
        hero.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(hero)

        pageHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(pageHost, LinearLayout.LayoutParams(-1, -2))
        logView = TextView(this).apply {
            text = "STATUS: Siap. Hubungkan Shizuku untuk fungsi modul ANGLE dan pembersihan cache."
            textSize = 10f; setTextColor(Color.rgb(218, 226, 238)); setPadding(dp(12), dp(12), dp(12), dp(12))
            background = gradient(intArrayOf(Color.rgb(19, 27, 40), Color.rgb(13, 18, 28)), dp(14))
        }
        root.addView(logView, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        root.addView(label("FRX TOOLS • FaruqExe", 9f, muted, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) })
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
        showPage("home")
    }

    private fun showPage(page: String) {
        val host = pageHost ?: return
        host.removeAllViews()
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(14), 0, dp(8)) }
        val heading = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        if (page != "home") heading.addView(actionButton("‹ KEMBALI", false) { showPage("home") }, LinearLayout.LayoutParams(dp(112), dp(42)).apply { rightMargin = dp(10) })
        val title = when (page) { "info" -> "INFORMASI APLIKASI"; "graphics" -> "GRAFIK MINECRAFT"; "floating" -> "FLOATING TOOLS"; "settings" -> "PENGATURAN"; else -> "PUSAT KONTROL" }
        heading.addView(label(title, 16f, Color.WHITE, true)); content.addView(heading)

        when (page) {
            "home" -> {
                content.addView(label("Pilih kategori untuk membuka halaman fitur dan pengaturannya.", 11f, muted, false).apply { setPadding(0, dp(8), 0, dp(12)) })
                content.addView(menuCard("INFORMASI", "Detail aplikasi, modul, kompatibilitas, dan kredit", "ⓘ") { showPage("info") })
                content.addView(menuCard("GRAFIK MINECRAFT", "Preset visual, target game, LOD, apply dan restore", "▦") { showPage("graphics") })
                content.addView(menuCard("FLOATING TOOLS", "Bubble FRX, crosshair, screenshot, dan cache", "◉") { showPage("floating") })
                content.addView(menuCard("PENGATURAN", "Status Shizuku dan preferensi aplikasi", "⚙") { showPage("settings") })
            }
            "info" -> {
                content.addView(infoCard("TENTANG FRX TOOLS", "FRX TOOLS adalah aplikasi utilitas Android dengan modul pengaturan kompatibilitas grafis ANGLE, floating tools, crosshair, dan screenshot layar."))
                content.addView(infoCard("MODUL GRAFIK MINECRAFT BY FARUQ", "Modul shell asli GrafikMcByFaruq.sh tetap disertakan. Fungsinya mencakup pemeriksaan kompatibilitas perangkat, pengaturan preset yang tersedia, pemeriksaan status, dan pemulihan konfigurasi."))
                content.addView(infoCard("IZIN & KOMPATIBILITAS", "Minimum Android 10 (API 29). Floating memerlukan izin tampil di atas aplikasi lain. Shizuku diperlukan untuk perintah sistem. Screenshot memerlukan persetujuan perekaman layar dari Android."))
                content.addView(infoCard("INFORMASI PENGEMBANG", "Nama: FRX TOOLS\nDeveloper: FaruqExe\nPackage: $packageName\nModul: Grafik Minecraft By Faruq"))
                content.addView(actionButton("TIKTOK DEVELOPER ↗", false) { openLink("https://tiktok.com/@faruqexe") })
                content.addView(actionButton("WHATSAPP CHANNEL ↗", false) { openLink("https://whatsapp.com/channel/0029VbDuMJcBadmisROLuF18") })
            }
            "graphics" -> {
                content.addView(label("Pilih target game, preset, dan tingkat LOD sebelum menerapkan konfigurasi.", 11f, muted, false).apply { setPadding(0, dp(8), 0, dp(12)) })
                val game = card(); game.addView(label("TARGET GAME", 11f, red, true))
                val gameRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                gameRow.addView(actionButton("FREE FIRE", selectedGame == "ff") { selectedGame = "ff"; showPage("graphics") }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { rightMargin = dp(4) })
                gameRow.addView(actionButton("FREE FIRE MAX", selectedGame == "max") { selectedGame = "max"; showPage("graphics") }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(4) })
                game.addView(gameRow); content.addView(game)
                val preset = card(); preset.addView(label("PILIH PRESET", 11f, red, true))
                val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                listOf("smooth" to "SMOOTH", "pixel" to "PIXEL", "retro" to "RETRO").forEach { (key, text) ->
                    presetRow.addView(actionButton(text, selectedPreset == key) { selectedPreset = key; showPage("graphics") }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(3); rightMargin = dp(3) })
                }
                preset.addView(presetRow)
                val lod = label("LEVEL OF DETAIL (LOD): $selectedLod", 12f, Color.WHITE, true); preset.addView(lod)
                preset.addView(SeekBar(this).apply {
                    max = 3; progress = selectedLod - 1; progressTintList = android.content.res.ColorStateList.valueOf(red); thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { selectedLod = progress + 1; lod.text = "LEVEL OF DETAIL (LOD): $selectedLod" }
                        override fun onStartTrackingTouch(seekBar: SeekBar?) {}; override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                    })
                })
                content.addView(preset)
                content.addView(comparisonCard(selectedPreset))
                content.addView(actionButton("CEK KOMPATIBILITAS PERANGKAT", false) { runModule("check") })
                content.addView(actionButton("TERAPKAN KONFIGURASI ANGLE", true) { runModule("$selectedGame on $selectedPreset $selectedLod") })
                val restore = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                restore.addView(actionButton("PULIHKAN FF", false) { runModule("ff off") }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { rightMargin = dp(4) })
                restore.addView(actionButton("PULIHKAN MAX", false) { runModule("max off") }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(4) }); content.addView(restore)
                val status = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                status.addView(actionButton("STATUS FF", false) { runModule("ff status") }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { rightMargin = dp(4) })
                status.addView(actionButton("STATUS MAX", false) { runModule("max status") }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(4) }); content.addView(status)
            }
            "floating" -> {
                content.addView(infoCard("FLOATING MENU", "Bubble FRX dapat dipindahkan. Quick panel muncul di bagian bawah layar. Tekan CROSSHAIR untuk membuka panel kontrol terpisah; crosshair tidak aktif sebelum tombol ON ditekan."))
                content.addView(actionButton("AKTIFKAN FLOATING FRX", true) {
                    if (!android.provider.Settings.canDrawOverlays(this)) {
                        startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName")))
                        toast("Izinkan tampil di atas aplikasi lain, lalu tekan tombol lagi.")
                    } else { startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACTION_START)); toast("Floating FRX diaktifkan") }
                })
                content.addView(actionButton("MATIKAN FLOATING FRX", false) { startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACTION_STOP)) })
                content.addView(actionButton("SCREENSHOT LAYAR", false) { requestScreenshot() })
                content.addView(actionButton("CLEAR CACHE SISTEM", false) { runPrivileged("pm trim-caches 1G", "Permintaan pembersihan cache dikirim ke Android. Hasil bergantung pada kebijakan sistem.") })
            }
            "settings" -> {
                content.addView(infoCard("SHIZUKU", if (Shizuku.pingBinder()) "Layanan Shizuku terdeteksi." else "Shizuku belum terhubung. Hubungkan melalui aplikasi Shizuku untuk menjalankan perintah sistem."))
                content.addView(actionButton("MINTA IZIN SHIZUKU", true) {
                    if (Shizuku.pingBinder()) { if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) toast("Izin Shizuku sudah diberikan.") else Shizuku.requestPermission(501) }
                    else toast("Jalankan dan hubungkan aplikasi Shizuku terlebih dahulu.")
                })
                content.addView(infoCard("SCREENSHOT", "Hasil screenshot disimpan ke Pictures/FRX TOOLS. Android akan meminta persetujuan perekaman layar saat diperlukan."))
            }
        }
        host.addView(content, LinearLayout.LayoutParams(-1, -2))
    }

    private fun menuCard(title: String, subtitle: String, glyph: String, action: () -> Unit): View {
        val item = card().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; isClickable = true; isFocusable = true; setOnClickListener { action() } }
        item.addView(label(glyph, 25f, red, true), LinearLayout.LayoutParams(dp(48), dp(48)))
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label(title, 13f, Color.WHITE, true)); texts.addView(label(subtitle, 9f, muted, false))
        item.addView(texts, LinearLayout.LayoutParams(0, -2, 1f)); item.addView(label("›", 24f, red, true))
        return item
    }

    private fun infoCard(title: String, body: String): View {
        val item = card(); item.addView(label(title, 11f, red, true))
        item.addView(label(body, 11f, Color.rgb(218, 226, 238), false).apply { setPadding(0, dp(7), 0, 0) })
        return item
    }


    private fun comparisonCard(mode: String): View {
        val c = card()
        c.addView(label("PERBANDINGAN BEFORE / AFTER", 12f, Color.WHITE, true))
        c.addView(label("Geser garis di tengah untuk membandingkan tampilan asli dan hasil preset ${mode.uppercase()}.", 10f, muted, false).apply { setPadding(0, dp(5), 0, dp(9)) })
        val preview = ComparisonPreview(this, mode)
        c.addView(preview, LinearLayout.LayoutParams(-1, dp(174)))
        val tags = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        tags.addView(label("◀ ORIGINAL", 10f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        tags.addView(label("AFTER PRESET ▶", 10f, Color.rgb(94, 220, 155), true).apply { gravity = Gravity.END })
        c.addView(tags)
        c.addView(label("Preview memakai screenshot gameplay Minecraft asli. Sisi AFTER adalah simulasi filter visual, bukan hasil render ANGLE langsung.", 9f, muted, false).apply { setPadding(0, dp(8), 0, 0) })
        c.addView(label("Image: Xbox México • CC BY 3.0 • Wikimedia Commons", 8f, muted, false).apply { setPadding(0, dp(4), 0, 0) })
        return c
    }

    private inner class ComparisonPreview(context: Context, private val mode: String) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private var split = 0.5f
        private val corner = dp(10).toFloat()
        private val source: Bitmap? = try {
            assets.open("minecraft_block_breaking.jpg").use { BitmapFactory.decodeStream(it) }
        } catch (_: Exception) { null }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            if (w <= 0f || h <= 0f) return
            val save = canvas.save()
            val outer = Path().apply { addRoundRect(0f, 0f, w, h, corner, corner, Path.Direction.CW) }
            canvas.clipPath(outer)
            val image = source
            if (image == null) {
                paint.color = Color.rgb(25, 34, 48)
                canvas.drawColor(paint.color)
                paint.color = Color.WHITE; paint.textSize = dp(12).toFloat(); paint.textAlign = Paint.Align.CENTER
                canvas.drawText("Screenshot Minecraft belum dimuat", w / 2f, h / 2f, paint)
                paint.textAlign = Paint.Align.LEFT
            } else {
                val dst = RectF(0f, 0f, w, h)
                paint.colorFilter = null
                paint.isFilterBitmap = true
                canvas.drawBitmap(image, null, dst, paint)
                val cut = w * split.coerceIn(0.08f, 0.92f)
                canvas.save()
                canvas.clipRect(cut, 0f, w, h)
                drawPresetPreview(canvas, image, dst)
                canvas.restore()

                paint.colorFilter = null
                paint.color = Color.WHITE
                paint.strokeWidth = dp(3).toFloat()
                canvas.drawLine(cut, 0f, cut, h, paint)
                paint.color = Color.argb(90, 0, 0, 0)
                canvas.drawCircle(cut, h * 0.5f, dp(18).toFloat(), paint)
                paint.color = Color.WHITE
                canvas.drawCircle(cut, h * 0.5f, dp(15).toFloat(), paint)
                paint.color = Color.rgb(29, 40, 54)
                paint.strokeWidth = dp(1.8f).toFloat()
                paint.style = Paint.Style.STROKE
                canvas.drawLine(cut - dp(5), h * .5f, cut - dp(1), h * .5f, paint)
                canvas.drawLine(cut + dp(1), h * .5f, cut + dp(5), h * .5f, paint)
                paint.style = Paint.Style.FILL
            }
            canvas.restoreToCount(save)
        }

        private fun drawPresetPreview(canvas: Canvas, image: Bitmap, dst: RectF) {
            paint.isFilterBitmap = mode != "pixel"
            paint.colorFilter = when (mode) {
                "smooth" -> ColorMatrixColorFilter(ColorMatrix(floatArrayOf(
                    1.08f, 0f, 0f, 0f, 5f,
                    0f, 1.08f, 0f, 0f, 5f,
                    0f, 0f, 1.08f, 0f, 5f,
                    0f, 0f, 0f, 1f, 0f
                )))
                "retro" -> ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0.68f) })
                else -> ColorMatrixColorFilter(ColorMatrix(floatArrayOf(
                    1.12f, 0f, 0f, 0f, 0f,
                    0f, 1.12f, 0f, 0f, 0f,
                    0f, 0f, 1.12f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )))
            }
            if (mode == "pixel") {
                val small = Bitmap.createScaledBitmap(image, (image.width / 7).coerceAtLeast(1), (image.height / 7).coerceAtLeast(1), false)
                canvas.drawBitmap(small, null, dst, paint)
                if (small !== image && !small.isRecycled) small.recycle()
            } else {
                canvas.drawBitmap(image, null, dst, paint)
            }
            paint.colorFilter = null
            paint.isFilterBitmap = true
            if (mode == "retro") {
                paint.color = Color.argb(32, 220, 150, 75)
                canvas.drawRect(dst, paint)
            }
        }

        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN, android.view.MotionEvent.ACTION_MOVE -> {
                    split = (event.x / width.coerceAtLeast(1)).coerceIn(0.08f, 0.92f)
                    invalidate()
                    return true
                }
                android.view.MotionEvent.ACTION_UP -> { performClick(); return true }
            }
            return true
        }

        override fun performClick(): Boolean { super.performClick(); return true }
    }

    private fun previewCard(title: String, subtitle: String, mode: String): View {
        val c = card().apply {
            setPadding(dp(10), dp(10), dp(10), dp(10))
            layoutParams = LinearLayout.LayoutParams(dp(176), -2).apply { rightMargin = dp(9) }
        }
        c.addView(GraphicPreview(this, mode), LinearLayout.LayoutParams(dp(154), dp(102)))
        c.addView(label(title, 13f, Color.WHITE, true).apply { setPadding(0, dp(9), 0, dp(2)) })
        c.addView(label(subtitle, 10f, muted, false))
        c.addView(actionButton("PILIH $title", selectedPreset == mode) { selectedPreset = mode; toast("Preset $title dipilih"); showPage("graphics") }, LinearLayout.LayoutParams(-1, dp(38)).apply { topMargin = dp(8) })
        return c
    }

    private fun sectionTitle(parent: LinearLayout, title: String, subtitle: String) {
        parent.addView(label(title, 13f, red, true).apply { setPadding(dp(2), dp(20), 0, dp(3)); letterSpacing = 0.08f })
        parent.addView(label(subtitle, 10f, muted, false).apply { setPadding(dp(2), 0, 0, dp(9)) })
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = gradient(intArrayOf(panel, Color.rgb(13, 18, 28)), dp(17))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) }
    }

    private fun label(textValue: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = textValue; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    private fun actionButton(textValue: String, active: Boolean, action: () -> Unit): Button = Button(this).apply {
        text = textValue; isAllCaps = false; textSize = 11f; minHeight = 0; minimumHeight = 0
        setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif", Typeface.BOLD)
        background = gradient(if (active) intArrayOf(Color.rgb(255, 65, 78), Color.rgb(178, 28, 45)) else intArrayOf(Color.rgb(38, 49, 66), Color.rgb(25, 34, 48)), dp(11))
        stateListAnimator = null
        setOnClickListener { action() }
    }

    private fun gradient(colors: IntArray, radius: Int): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply { cornerRadius = radius.toFloat() }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun openLink(url: String) { try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))) } catch (_: Exception) { toast("Tidak ada aplikasi untuk membuka tautan.") } }

    private fun runModule(args: String) {
        try {
            if (!Shizuku.pingBinder()) { showLog("Shizuku belum aktif. Jalankan aplikasi Shizuku dan hubungkan layanan terlebih dahulu."); return }
            if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) { Shizuku.requestPermission(501); showLog("Menunggu izin Shizuku. Setelah diizinkan, tekan tombol lagi."); return }
            Thread {
                try {
                    val command = arrayOf("sh", "-s", "--") + args.trim().split(Regex("\\s+")).toTypedArray()
                    val process = Shizuku.newProcess(command, null, null)
                    assets.open("GrafikMcByFaruq.sh").bufferedReader().use { script -> process.outputStream.bufferedWriter().use { input -> input.write(script.readText()) } }
                    val output = process.inputStream.bufferedReader().readText(); val error = process.errorStream.bufferedReader().readText(); val code = process.waitFor()
                    runOnUiThread { showLog("Menjalankan modul: $args\nExit: $code\n$output\n$error".trim()) }
                } catch (e: Exception) { runOnUiThread { showLog("Gagal menjalankan modul: ${e.message}") } }
            }.start()
        } catch (e: Exception) { showLog("Shizuku error: ${e.message}") }
    }

    private fun runPrivileged(command: String, successText: String) {
        try {
            if (!Shizuku.pingBinder()) { showLog("Shizuku belum aktif. Jalankan aplikasi Shizuku dan hubungkan layanan terlebih dahulu."); return }
            if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) { Shizuku.requestPermission(501); showLog("Menunggu izin Shizuku. Setelah diizinkan, tekan tombol lagi."); return }
            Thread {
                try {
                    val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
                    val output = process.inputStream.bufferedReader().readText(); val error = process.errorStream.bufferedReader().readText(); val code = process.waitFor()
                    runOnUiThread { showLog("$successText\nExit: $code\n$output\n$error".trim()) }
                } catch (e: Exception) { runOnUiThread { showLog("Gagal menjalankan perintah: ${e.message}") } }
            }.start()
        } catch (e: Exception) { showLog("Shizuku error: ${e.message}") }
    }

    private fun requestScreenshot() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), screenshotRequest)
    }

    @Deprecated("MediaProjection consent callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != screenshotRequest) return
        if (resultCode != RESULT_OK || data == null) { toast("Screenshot dibatalkan."); return }
        val serviceIntent = Intent(this, CaptureService::class.java).apply { putExtra(CaptureService.EXTRA_RESULT, resultCode); putExtra(CaptureService.EXTRA_DATA, data) }
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
        toast("Permintaan screenshot diterima. Hasil masuk Pictures/FRX TOOLS.")
    }

    private fun showLog(message: String) { logView.text = message }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private inner class GraphicPreview(context: Context, private val mode: String) : View(context) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            val colors = when (mode) {
                "pixel" -> intArrayOf(Color.rgb(23, 39, 62), Color.rgb(52, 79, 103))
                "retro" -> intArrayOf(Color.rgb(48, 35, 59), Color.rgb(118, 63, 68))
                else -> intArrayOf(Color.rgb(16, 55, 67), Color.rgb(67, 126, 132))
            }
            p.shader = LinearGradient(0f, 0f, 0f, h, colors[0], colors[1], Shader.TileMode.CLAMP)
            canvas.drawRoundRect(0f, 0f, w, h, dp(10).toFloat(), dp(10).toFloat(), p)
            p.shader = null
            // Stylized hills / terrain, intentionally illustrative rather than a game screenshot.
            p.color = when (mode) { "pixel" -> Color.rgb(56, 107, 91); "retro" -> Color.rgb(180, 111, 76); else -> Color.rgb(65, 151, 126) }
            if (mode == "pixel") {
                val block = w / 12f
                for (i in 0..11) {
                    val top = h * (0.48f + ((i * 7) % 4) * 0.045f)
                    canvas.drawRect(i * block, top, (i + 1) * block + 1, h, p)
                }
                p.color = Color.rgb(214, 185, 116)
                canvas.drawRect(w * .12f, h * .33f, w * .32f, h * .48f, p)
                canvas.drawRect(w * .69f, h * .25f, w * .88f, h * .47f, p)
            } else {
                val path = Path().apply { moveTo(0f, h * .66f); cubicTo(w * .25f, h * .37f, w * .47f, h * .83f, w, h * .48f); lineTo(w, h); lineTo(0f, h); close() }
                canvas.drawPath(path, p)
                p.color = if (mode == "retro") Color.rgb(228, 169, 103) else Color.rgb(122, 196, 151)
                canvas.drawCircle(w * .76f, h * .25f, h * .105f, p)
                p.color = Color.argb(110, 8, 15, 24)
                canvas.drawOval(w * .12f, h * .67f, w * .48f, h * .83f, p)
            }
            if (mode == "retro") {
                p.color = Color.argb(38, 255, 232, 190); p.strokeWidth = 1f
                var y = 3f; while (y < h) { canvas.drawLine(0f, y, w, y, p); y += 4f }
                p.color = Color.rgb(255, 210, 144); p.style = Paint.Style.STROKE; p.strokeWidth = dp(1).toFloat()
                canvas.drawRoundRect(4f, 4f, w - 4f, h - 4f, dp(7).toFloat(), dp(7).toFloat(), p); p.style = Paint.Style.FILL
            }
            if (mode == "smooth") {
                p.color = Color.argb(45, 255, 255, 255)
                canvas.drawRoundRect(w * .08f, h * .08f, w * .92f, h * .18f, h * .05f, h * .05f, p)
            }
        }
    }
}
