package com.frx.tools

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.widget.Toast

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private val handler = Handler(Looper.getMainLooper())
    private var restoreFloatingAfterCapture = false
    private var floatingRestoreSent = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT, 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        restoreFloatingAfterCapture = intent?.getBooleanExtra(EXTRA_RESTORE_FLOATING, false) ?: false
        if (resultCode == 0 || data == null) { restoreFloating(); stopSelf(); return START_NOT_STICKY }
        startCaptureNotification()
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            val metrics = resources.displayMetrics
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    try { display?.release() } catch (_: Exception) {}
                    try { reader?.close() } catch (_: Exception) {}
                    display = null; reader = null; projection = null
                    stopForeground(true)
                    restoreFloating()
                    stopSelf()
                }
            }, handler)
            display = projection?.createVirtualDisplay("FRX-Screenshot", width, height, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
            handler.postDelayed({ saveImage() }, 1000)
        } catch (e: Exception) {
            Toast.makeText(this, "Screenshot gagal: ${e.message}", Toast.LENGTH_LONG).show()
            cleanup()
        }
        return START_NOT_STICKY
    }

    private fun startCaptureNotification() {
        val channelId = "frx_capture"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "FRX Screenshot", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId).setContentTitle("FRX TOOLS")
                .setContentText("Mengambil screenshot layar…")
                .setSmallIcon(android.R.drawable.ic_menu_camera).setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("FRX TOOLS").setContentText("Mengambil screenshot layar…")
                .setSmallIcon(android.R.drawable.ic_menu_camera).setOngoing(true).build()
        }
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(77, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(77, notification)
    }

    private fun saveImage() {
        try {
            val image = reader?.acquireLatestImage() ?: throw IllegalStateException("Frame belum tersedia. Coba screenshot lagi.")
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowPadding = plane.rowStride - pixelStride * image.width
            val padded = Bitmap.createBitmap(image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888)
            padded.copyPixelsFromBuffer(buffer)
            val bitmap = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
            image.close(); padded.recycle()
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "FRX_${System.currentTimeMillis()}.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FRX TOOLS")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Tidak bisa membuat file gambar.")
            contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            bitmap.recycle()
            Toast.makeText(this, "Screenshot tersimpan: Pictures/FRX TOOLS", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Screenshot gagal: ${e.message}", Toast.LENGTH_LONG).show()
        } finally { cleanup() }
    }

    private fun cleanup() {
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        val activeProjection = projection
        projection = null
        display = null; reader = null
        try { activeProjection?.stop() } catch (_: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        restoreFloating()
        stopSelf()
    }

    private fun restoreFloating() {
        if (!restoreFloatingAfterCapture || floatingRestoreSent) return
        floatingRestoreSent = true
        startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACTION_RESTORE))
    }

    companion object {
        const val EXTRA_RESULT = "capture_result_code"
        const val EXTRA_DATA = "capture_result_data"
        const val EXTRA_RESTORE_FLOATING = "restore_floating_after_capture"
    }
}
