# FRX TOOLS — FaruqExe

Android project untuk FRX TOOLS dengan UI gaming modern bertema dark / red.

## Perubahan UI
- Header logo FRX TOOLS berbasis vector drawable (scalable / tajam di berbagai resolusi).
- Label developer: FaruqExe.
- Tombol TikTok: https://tiktok.com/@faruqexe
- Tombol Saluran WhatsApp: https://whatsapp.com/channel/0029VbDuMJcBadmisROLuF18
- Kartu preview ilustratif untuk preset Pixel, Smooth, dan Retro.
- Pengaturan ukuran crosshair dihapus. Radius crosshair memakai nilai tetap; warna, bentuk, ketebalan, dan posisi masih tersedia.
- Modul shell Grafik Minecraft, Shizuku, screenshot, clear cache, dan floating tools tetap disertakan.

## Catatan preview
Kartu Pixel / Smooth / Retro adalah ilustrasi visual untuk membantu membandingkan karakter preset. Itu bukan screenshot game dan bukan jaminan tampilan game persis sama; hasil aktual tergantung perangkat, versi Android, game, dan dukungan ANGLE.

## Build
Project Android ada di folder `GrafikMcByFaruq`. Workflow GitHub Actions sengaja tidak disertakan dalam ZIP; buat file `.github/workflows/build.yml` secara terpisah di repository.

Build lokal / CI menggunakan Java 17 dan Gradle 8.7:

```bash
cd GrafikMcByFaruq
gradle assembleDebug --no-daemon
```

APK debug dihasilkan di `app/build/outputs/apk/debug/app-debug.apk`.

## Floating menu update (FIX2)
- Menghapus lingkaran penanda kecil di samping crosshair; sekarang hanya satu crosshair yang digambar.
- Floating control panel tampil di tengah layar dengan animasi masuk dari bawah dan animasi keluar.
- Tombol menu floating diubah menjadi tile ikon bulat dengan nama fitur di bawah ikon, bergaya gaming/ROG.
- Pengaturan warna, bentuk, ketebalan, posisi X/Y, screenshot, clear cache, tutup menu, dan exit tetap tersedia.
