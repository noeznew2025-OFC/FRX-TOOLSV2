package com.frx.tools

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class FloatingService : Service() {
    companion object {
        const val ACTION_START = "com.frx.tools.START_FLOATING"
        const val ACTION_STOP = "com.frx.tools.STOP_FLOATING"
    }

    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var crosshair: CrosshairView? = null
    private var crosshairParams: WindowManager.LayoutParams? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var colorIndex = 0
    private var shapeIndex = 0
    private var thickness = 4
    private var posX = 0
    private var posY = 0
    private val colors = intArrayOf(Color.RED, Color.WHITE, Color.GREEN, Color.CYAN, Color.YELLOW, Color.MAGENTA)
    private val shapes = arrayOf("PLUS", "CROSS", "DOT", "CIRCLE")

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopSelf()
            else -> showOverlay()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun overlayType() = if (android.os.Build.VERSION.SDK_INT >= 26)
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    private fun baseParams(w: Int, h: Int, gravity: Int) = WindowManager.LayoutParams(
        w, h, overlayType(),
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { this.gravity = gravity }

    private fun showOverlay() {
        if (!android.provider.Settings.canDrawOverlays(this) || bubble != null) return
        startFloatingForeground()
        crosshair = CrosshairView().also { view ->
            val params = baseParams(-1, -1, Gravity.TOP or Gravity.START).apply {
                flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            }
            crosshairParams = params
            wm.addView(view, params)
        }
        bubble = TextView(this).apply {
            text = "FRX"
            textSize = 20f
            setTextColor(0xFFFF4658.toInt())
            typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 8)
            setBackgroundColor(Color.TRANSPARENT)
            setShadowLayer(dp(7).toFloat(), 0f, 0f, 0xFFFF263F.toInt())
            setOnTouchListener(BubbleTouch())
        }
        val bParams = baseParams(dp(58), dp(48), Gravity.TOP or Gravity.START).apply {
            x = dp(12)
            y = dp(160)
        }
        bubbleParams = bParams
        bubble?.let { wm.addView(it, bParams) }
    }

    private inner class BubbleTouch : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var dragged = false

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val p = bubbleParams ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = p.x
                    startY = p.y
                    dragged = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > 8) dragged = true
                    p.x = startX + dx
                    p.y = startY + dy
                    bubble?.let { wm.updateViewLayout(it, p) }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragged) togglePanel()
                    return true
                }
            }
            return false
        }
    }

    private fun togglePanel() {
        if (panel != null) {
            removePanel()
            return
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xF51B2638.toInt(), 0xF5101724.toInt())
            ).apply {
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), 0xFF42536C.toInt())
            }
            alpha = 0f
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        heading.addView(TextView(this).apply {
            text = "FRX CONTROL CENTER"
            textSize = 16f
            setTextColor(0xFFFF4658.toInt())
            typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.BOLD)
        })
        heading.addView(TextView(this).apply {
            text = "ROG QUICK PANEL  •  FLOATING TOOLS"
            textSize = 9f
            setTextColor(0xFF9EADC2.toInt())
        })
        header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(roundIcon("×", "TUTUP") { removePanel() })
        box.addView(header)

        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(15), 0, dp(8))
        }
        addFeatureRow(grid, listOf(
            Feature("🎨", "WARNA") {
                colorIndex = (colorIndex + 1) % colors.size
                refreshCrosshair()
                removePanel()
                togglePanel()
            },
            Feature("✛", "BENTUK") {
                shapeIndex = (shapeIndex + 1) % shapes.size
                refreshCrosshair()
                removePanel()
                togglePanel()
            },
            Feature("🧹", "CACHE") { clearSystemCache() }
        ))
        addFeatureRow(grid, listOf(
            Feature("▣", "SCREENSHOT") {
                val i = Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .setAction(MainActivity.ACTION_SCREENSHOT)
                startActivity(i)
            },
            Feature("⌄", "TUTUP MENU") { removePanel() },
            Feature("⏻", "EXIT") { stopSelf() }
        ))
        box.addView(grid)

        box.addView(TextView(this).apply {
            text = "CROSSHAIR SETTINGS"
            textSize = 10f
            setTextColor(0xFFFF6572.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, dp(5), 0, dp(2))
        })
        addSeek(box, "KETEBALAN", 1, 14, thickness) { thickness = it; refreshCrosshair() }
        addSeek(box, "POSISI X", -400, 400, posX) { posX = it; refreshCrosshair() }
        addSeek(box, "POSISI Y", -700, 700, posY) { posY = it; refreshCrosshair() }

        panel = box
        val pParams = baseParams(dp(326), -2, Gravity.CENTER).apply {
            x = 0
            y = 0
        }
        panelParams = pParams
        try {
            wm.addView(box, pParams)
            box.translationY = (resources.displayMetrics.heightPixels * 0.42f)
            box.animate()
                .translationY(0f)
                .alpha(1f)
                .setDuration(420)
                .setInterpolator(DecelerateInterpolator())
                .start()
        } catch (_: Exception) {
            panel = null
            panelParams = null
            Toast.makeText(this, "Tidak dapat menampilkan menu overlay.", Toast.LENGTH_SHORT).show()
        }
    }

    private data class Feature(val icon: String, val label: String, val action: () -> Unit)

    private fun addFeatureRow(parent: LinearLayout, features: List<Feature>) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        features.forEach { feature ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(3), dp(5), dp(3), dp(5))
                isClickable = true
                isFocusable = true
                setOnClickListener { feature.action() }
            }
            val icon = TextView(this).apply {
                text = feature.icon
                textSize = 23f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    colors = intArrayOf(0xFF34465F.toInt(), 0xFF1A2639.toInt())
                    setStroke(dp(1), 0xFF596D89.toInt())
                }
                elevation = dp(4).toFloat()
            }
            tile.addView(icon, LinearLayout.LayoutParams(dp(54), dp(54)))
            tile.addView(TextView(this).apply {
                text = feature.label
                textSize = 9f
                gravity = Gravity.CENTER
                setTextColor(0xFFE4EAF3.toInt())
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                maxLines = 1
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
            row.addView(tile, LinearLayout.LayoutParams(0, -2, 1f))
        }
        parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
    }

    private fun roundIcon(glyph: String, description: String, action: () -> Unit): View {
        return TextView(this).apply {
            text = glyph
            contentDescription = description
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF34465F.toInt())
                setStroke(dp(1), 0xFF596D89.toInt())
            }
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
        }
    }

    private fun addSeek(parent: LinearLayout, label: String, min: Int, max: Int, initial: Int, changed: (Int) -> Unit) {
        val valueLabel = TextView(this).apply {
            text = "$label: $initial"
            setTextColor(0xFFD5DEEA.toInt())
            textSize = 10f
        }
        parent.addView(valueLabel)
        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = (initial - min).coerceIn(0, max - min)
            progressTintList = android.content.res.ColorStateList.valueOf(0xFFFF4658.toInt())
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = progress + min
                valueLabel.text = "$label: $value"
                changed(value)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(seek, LinearLayout.LayoutParams(-1, dp(30)))
    }

    private fun clearSystemCache() {
        if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Hubungkan Shizuku dan berikan izin dari aplikasi FRX TOOLS terlebih dahulu.", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        Thread {
            try {
                val p = Shizuku.newProcess(arrayOf("sh", "-c", "pm trim-caches 1G"), null, null)
                val out = p.inputStream.bufferedReader().readText()
                val err = p.errorStream.bufferedReader().readText()
                val code = p.waitFor()
                android.os.Handler(mainLooper).post {
                    Toast.makeText(this, if (code == 0) "Permintaan clear cache selesai diproses." else "Clear cache gagal: $err $out", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                android.os.Handler(mainLooper).post {
                    Toast.makeText(this, "Clear cache gagal: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun removePanel() {
        val current = panel ?: return
        panel = null
        panelParams = null
        current.animate()
            .alpha(0f)
            .translationY(dp(180).toFloat())
            .setDuration(170)
            .withEndAction { try { wm.removeView(current) } catch (_: Exception) {} }
            .start()
    }

    private fun refreshCrosshair() { crosshair?.invalidate() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun startFloatingForeground() {
        val channelId = "frx_floating"
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val channel = android.app.NotificationChannel(channelId, "FRX Floating Menu", android.app.NotificationManager.IMPORTANCE_LOW)
            getSystemService(android.app.NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = if (android.os.Build.VERSION.SDK_INT >= 26) {
            android.app.Notification.Builder(this, channelId).setContentTitle("FRX TOOLS aktif")
                .setContentText("Floating crosshair sedang berjalan")
                .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            android.app.Notification.Builder(this).setContentTitle("FRX TOOLS aktif")
                .setContentText("Floating crosshair sedang berjalan")
                .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build()
        }
        startForeground(76, notification)
    }

    private inner class CrosshairView : View(this) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f + dp(posX).toFloat()
            val cy = height / 2f + dp(posY).toFloat()
            val r = dp(34).toFloat()
            paint.color = colors[colorIndex]
            paint.strokeWidth = dp(thickness).toFloat()
            paint.strokeCap = Paint.Cap.ROUND
            when (shapes[shapeIndex]) {
                "PLUS" -> {
                    canvas.drawLine(cx - r, cy, cx - r / 3, cy, paint)
                    canvas.drawLine(cx + r / 3, cy, cx + r, cy, paint)
                    canvas.drawLine(cx, cy - r, cx, cy - r / 3, paint)
                    canvas.drawLine(cx, cy + r / 3, cx, cy + r, paint)
                }
                "CROSS" -> {
                    canvas.drawLine(cx - r, cy - r, cx + r, cy + r, paint)
                    canvas.drawLine(cx - r, cy + r, cx + r, cy - r, paint)
                }
                "DOT" -> {
                    paint.style = Paint.Style.FILL
                    canvas.drawCircle(cx, cy, dp(thickness + 2).toFloat(), paint)
                    paint.style = Paint.Style.STROKE
                }
                "CIRCLE" -> canvas.drawCircle(cx, cy, r, paint)
            }
            // No extra side marker: only one crosshair is drawn on screen.
        }
    }

    override fun onDestroy() {
        removePanel()
        listOfNotNull(bubble, crosshair).forEach { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        crosshair = null
        stopForeground(true)
        super.onDestroy()
    }
}
