# FRX TOOLS • FaruqExe

## Floating crosshair
- Mengaktifkan Floating Menu tidak otomatis menampilkan crosshair.
- Buka tile CROSSHAIR untuk membuka panel kontrol terpisah.
- Tekan tombol OFF/ON di panel CROSSHAIR CONTROL untuk mengaktifkan atau mematikan crosshair.
- Saat Floating Service dimulai ulang, crosshair kembali dalam keadaan OFF.

Modul shell `GrafikMcByFaruq.sh` tetap disertakan.


## Screenshot dari floating menu
- Menekan SCREENSHOT menyembunyikan overlay FRX sementara dan meminta izin perekaman layar melalui dialog resmi Android.
- Activity izin memakai tema transparan agar halaman utama FRX tidak terbuka dan game tetap terlihat di belakang dialog sistem.
- Setelah izin disetujui, frame game disimpan ke Pictures/FRX TOOLS lalu bubble FRX dipulihkan.
- Dialog persetujuan MediaProjection Android tetap wajib dan tidak dapat dilewati.

## Navigasi aplikasi
- Halaman utama dipisah menjadi Informasi, Grafik Minecraft, Floating Tools, dan Pengaturan.
- Pengaturan Grafik Minecraft berada pada halaman tersendiri; modul shell asli tetap disertakan.
- Quick panel floating muncul dekat bagian bawah layar.
