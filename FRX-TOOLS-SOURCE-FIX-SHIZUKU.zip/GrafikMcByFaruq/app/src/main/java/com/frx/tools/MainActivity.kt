package com.frx.tools

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.hardware.display.DisplayManager
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.content.ContentValues
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.io.File
import java.nio.ByteBuffer

class MainActivity : Activity() {
    companion object { const val ACTION_SCREENSHOT = "com.frx.tools.REQUEST_SCREENSHOT" }
    private lateinit var logView: TextView
    private val screenshotRequest = 710
    private var selectedGame = "ff"
    private var selectedPreset = "smooth"
    private var selectedLod = 2
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (intent?.action == ACTION_SCREENSHOT) handler.postDelayed({ requestScreenshot() }, 350)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 24)
            setBackgroundColor(0xFF090909.toInt())
        }
        val title = TextView(this).apply {
            text = "FRX TOOLS"
            textSize = 30f
            setTextColor(0xFFFF3434.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(title)
        root.addView(TextView(this).apply {
            text = "ROG GAMING CONTROL  •  FARUQ EDITION"
            textSize = 11f
            setTextColor(0xFFAAAAAA.toInt())
            setPadding(0, 2, 0, 20)
        })
        addButton(root, "AKTIFKAN FLOATING FRX") {
            if (!android.provider.Settings.canDrawOverlays(this)) {
                startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    android.net.Uri.parse("package:$packageName")))
                toast("Izinkan tampil di atas aplikasi lain, lalu tekan tombol lagi.")
            } else {
                startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACTION_START))
                toast("Floating FRX diaktifkan")
            }
        }
        addButton(root, "MATIKAN FLOATING FRX") {
            startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACTION_STOP))
        }
        addButton(root, "CEK KOMPATIBILITAS PERANGKAT") { runModule("check") }
        root.addView(TextView(this).apply { text = "PILIH GAME"; setTextColor(0xFFFF5555.toInt()); setPadding(0, 12, 0, 2) })
        addButton(root, "GAME: FREE FIRE BIASA") { selectedGame = "ff"; toast("Game dipilih: Free Fire biasa") }
        addButton(root, "GAME: FREE FIRE MAX") { selectedGame = "max"; toast("Game dipilih: Free Fire MAX") }
        root.addView(TextView(this).apply { text = "PILIH PRESET"; setTextColor(0xFFFF5555.toInt()); setPadding(0, 12, 0, 2) })
        addButton(root, "PRESET: SMOOTH") { selectedPreset = "smooth"; toast("Preset Smooth dipilih") }
        addButton(root, "PRESET: PIXEL") { selectedPreset = "pixel"; toast("Preset Pixel dipilih") }
        addButton(root, "PRESET: RETRO") { selectedPreset = "retro"; toast("Preset Retro dipilih") }
        val lodLabel = TextView(this).apply { text = "LOD: 2"; setTextColor(0xFFFFFFFF.toInt()); setPadding(0, 12, 0, 2) }
        root.addView(lodLabel)
        root.addView(SeekBar(this).apply {
            max = 3; progress = 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { selectedLod = progress + 1; lodLabel.text = "LOD: $selectedLod" }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        })
        addButton(root, "TERAPKAN KONFIGURASI ANGLE") { runModule("$selectedGame on $selectedPreset $selectedLod") }
        addButton(root, "PULIHKAN FREE FIRE") { runModule("ff off") }
        addButton(root, "PULIHKAN FREE FIRE MAX") { runModule("max off") }
        addButton(root, "STATUS FREE FIRE") { runModule("ff status") }
        addButton(root, "STATUS FREE FIRE MAX") { runModule("max status") }
        addButton(root, "CLEAR CACHE SISTEM") {
            runPrivileged("pm trim-caches 1G", "Permintaan pembersihan cache dikirim ke Android. Hasil bergantung pada kebijakan sistem.")
        }
        addButton(root, "SCREENSHOT LAYAR") { requestScreenshot() }
        logView = TextView(this).apply {
            text = "STATUS: Siap. Hubungkan Shizuku untuk fungsi modul ANGLE dan pembersihan cache."
            textSize = 12f
            setTextColor(0xFFE0E0E0.toInt())
            setPadding(12, 16, 12, 16)
            setBackgroundColor(0xFF171717.toInt())
        }
        root.addView(logView, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 14 })
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFFB51F28.toInt())
            setOnClickListener { action() }
        }
        parent.addView(button, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 6 })
    }

    private fun runModule(args: String) {
        try {
            if (!Shizuku.pingBinder()) {
                showLog("Shizuku belum aktif. Jalankan aplikasi Shizuku dan hubungkan layanan terlebih dahulu.")
                return
            }
            if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(501)
                showLog("Menunggu izin Shizuku. Setelah diizinkan, tekan tombol lagi.")
                return
            }
            Thread {
                try {
                    val command = arrayOf("sh", "-s", "--") + args.trim().split(Regex("\\s+")).toTypedArray()
                    val process = Shizuku.newProcess(command, null, null)
                    assets.open("GrafikMcByFaruq.sh").bufferedReader().use { script ->
                        process.outputStream.bufferedWriter().use { input -> input.write(script.readText()) }
                    }
                    val output = process.inputStream.bufferedReader().readText()
                    val error = process.errorStream.bufferedReader().readText()
                    val code = process.waitFor()
                    runOnUiThread { showLog("Menjalankan modul: $args\nExit: $code\n$output\n$error".trim()) }
                } catch (e: Exception) {
                    runOnUiThread { showLog("Gagal menjalankan modul: ${e.message}") }
                }
            }.start()
        } catch (e: Exception) { showLog("Shizuku error: ${e.message}") }
    }

    private fun runPrivileged(command: String, successText: String) {
        try {
            if (!Shizuku.pingBinder()) {
                showLog("Shizuku belum aktif. Jalankan aplikasi Shizuku dan hubungkan layanan terlebih dahulu.")
                return
            }
            if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(501)
                showLog("Menunggu izin Shizuku. Setelah diizinkan, tekan tombol lagi.")
                return
            }
            Thread {
                try {
                    val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
                    val output = process.inputStream.bufferedReader().readText()
                    val error = process.errorStream.bufferedReader().readText()
                    val code = process.waitFor()
                    runOnUiThread { showLog("$successText\nExit: $code\n${output}\n${error}".trim()) }
                } catch (e: Exception) {
                    runOnUiThread { showLog("Gagal menjalankan perintah: ${e.message}") }
                }
            }.start()
        } catch (e: Exception) { showLog("Shizuku error: ${e.message}") }
    }

    private fun requestScreenshot() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), screenshotRequest)
    }

    @Deprecated("MediaProjection consent callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != screenshotRequest) return
        if (resultCode != RESULT_OK || data == null) { toast("Screenshot dibatalkan."); return }
        val serviceIntent = Intent(this, CaptureService::class.java).apply {
            putExtra(CaptureService.EXTRA_RESULT, resultCode)
            putExtra(CaptureService.EXTRA_DATA, data)
        }
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
        toast("Permintaan screenshot diterima. Hasil masuk Pictures/FRX TOOLS.")
    }

    private fun showLog(message: String) { logView.text = message }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
