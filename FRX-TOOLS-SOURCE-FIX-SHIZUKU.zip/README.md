# FRX TOOLS

Android project rebuilt from the supplied `GRAFIK MINECRAFT BY FARUQ` v2.0 shell module.

## Features in this starter build
- ROG-inspired dark/red dashboard.
- FRX floating overlay with draggable FRX text logo.
- Crosshair overlay: color, shape, size, thickness, X/Y position, and a small alignment marker.
- Android MediaProjection screenshot flow; saves to `Pictures/FRX TOOLS` after the user grants capture permission.
- Shizuku execution for the original ANGLE shell module and `pm trim-caches 1G` request.
- Original shell script is packaged at `app/src/main/assets/GrafikMcByFaruq.sh`.

## Requirements
- Android 10 (API 29) or newer.
- Shizuku installed and running for ANGLE configuration and system cache trim.
- Grant FRX TOOLS the "Display over other apps" permission for the floating menu.
- Screenshot requires accepting Android's screen-capture prompt each time.

## Build with GitHub Actions
1. Create a GitHub repository.
2. Upload the contents of this folder to the repository root (the `.github` folder must be at repository root).
3. Open **Actions** → **Build FRX TOOLS APK** → **Run workflow**.
4. When the run succeeds, open its summary and download the `FRX-TOOLS-APK` artifact.

The workflow builds `GrafikMcByFaruq/app` with Java 17 and Gradle 8.7.

## Notes
- `pm trim-caches 1G` asks Android to trim cache storage to help reach the requested free-space target; it does not guarantee clearing every app's cache.
- Android/ROM/game policy can block overlays or screenshot capture over protected content.
- Crosshair is a visual screen overlay only. It does not modify game files or game memory.
- The first source build has not been executed in this environment; GitHub Actions is the intended build/verification step.
