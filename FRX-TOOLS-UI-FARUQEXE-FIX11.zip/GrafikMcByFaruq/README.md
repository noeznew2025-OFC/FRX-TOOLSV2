# FRX TOOLS • FaruqExe

Android project using Java 17, Gradle 8.7, Android compileSdk 35, minSdk 29, and Shizuku API 12.2.0.

## Build with GitHub Actions

1. Put `FRX-TOOLS-UI-FARUQEXE-FIX11.zip` in the repository root.
2. Put the supplied workflow file at `.github/workflows/build.yml`.
3. Push to `main`/`master`, or run **Build FRX TOOLS APK** from the Actions tab.
4. Download the `FRX-TOOLS-APK` artifact after the workflow succeeds.

The workflow downloads the licensed Minecraft gameplay preview image into `app/src/main/assets` before building. The image is bundled into the APK, so the Grafik Minecraft preview does not need an internet connection at runtime. The preview is a visual sample; SMOOTH/PIXEL/RETRO remain illustrative filters and are not a live ANGLE render.

Image attribution: Xbox México, “Minecraft Beta 1.8.1 Gameplay Screenshot”, Wikimedia Commons, CC BY 3.0. Source: https://commons.wikimedia.org/wiki/File:Minecraft_Beta_1.8.1_Gameplay_Screenshot.png
License: https://creativecommons.org/licenses/by/3.0/

The original `GrafikMcByFaruq.sh` module remains in `app/src/main/assets/`.
