#!/data/data/com.termux/files/usr/bin/bash
set -e
if [ -z "${ANDROID_HOME:-}" ]; then
  echo "ERROR: ANDROID_HOME belum diatur. Pasang Android SDK platform 34 + build-tools 34.0.0 dahulu."
  exit 1
fi
if [ ! -d "$ANDROID_HOME/platforms/android-34" ] || [ ! -d "$ANDROID_HOME/build-tools/34.0.0" ]; then
  echo "ERROR: SDK platform 34 atau build-tools 34.0.0 belum ditemukan di $ANDROID_HOME"
  exit 1
fi
gradle --no-daemon assembleDebug
mkdir -p "$HOME/storage/shared/Download" 2>/dev/null || true
cp app/build/outputs/apk/debug/app-debug.apk "$HOME/storage/shared/Download/FRX-TOOLS-debug.apk"
echo "APK: ~/storage/shared/Download/FRX-TOOLS-debug.apk"
