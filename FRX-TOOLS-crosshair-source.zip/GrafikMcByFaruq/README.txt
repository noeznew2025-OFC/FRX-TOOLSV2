FRX-TOOLS — GRAFIK MINECRAFT BY FARUQ

FITUR YANG ADA DI PROJECT INI
- Fitur asli konfigurasi ANGLE/Shizuku untuk Free Fire dan Free Fire MAX tetap dipertahankan.
- Crosshair overlay: bentuk plus/circle/dot/square, warna, ukuran, dan offset X/Y dari titik tengah.
- Floating FRX: tombol ON/OFF di aplikasi, bubble FRX dapat dipindah, panel quick dan EXIT.
- Clear cache: hanya membersihkan cache milik FRX-TOOLS sendiri. Android membatasi aplikasi biasa untuk membersihkan cache game/aplikasi lain.

CATATAN PENTING
- Overlay memerlukan izin "Tampil di atas aplikasi lain".
- Shizuku harus aktif untuk fungsi konfigurasi ANGLE.
- Crosshair adalah overlay visual. Pastikan mengikuti aturan game yang digunakan.
- Tombol screenshot lintas-aplikasi dengan MediaProjection belum termasuk dalam build sumber ini; fitur itu membutuhkan persetujuan capture Android setiap sesi dan implementasi foreground service tersendiri.
- Clear cache bukan fitur peningkat FPS dan tidak dapat menjamin game bebas patah-patah.

BUILD DI TERMUX (ANDROID)
1. Install Termux dari sumber tepercaya, lalu jalankan:
   pkg update && pkg upgrade -y
   pkg install openjdk-17 curl unzip git -y
2. Pastikan Java 17 aktif:
   export JAVA_HOME=$PREFIX/opt/openjdk
   export PATH=$JAVA_HOME/bin:$PATH
   java -version
3. Install Gradle 8.7:
   cd $HOME
   curl -L https://services.gradle.org/distributions/gradle-8.7-bin.zip -o gradle-8.7-bin.zip
   unzip -q gradle-8.7-bin.zip
   export PATH=$HOME/gradle-8.7/bin:$PATH
4. Android SDK harus tersedia. Atur ANDROID_HOME ke folder SDK yang berisi platforms/android-34 dan build-tools/34.0.0.
   export ANDROID_HOME=$HOME/android-sdk
   export ANDROID_SDK_ROOT=$ANDROID_HOME
5. Dari folder project jalankan:
   gradle --no-daemon assembleDebug
6. APK jika build berhasil:
   app/build/outputs/apk/debug/app-debug.apk

CATATAN BUILD TERMUX
Android SDK resmi (platform 34 dan build-tools 34.0.0) harus dipasang terlebih dahulu. Jika SDK belum ada, build akan gagal dengan pesan "SDK location not found" atau platform/build-tools tidak ditemukan. Buat file local.properties di folder project dengan isi:
   sdk.dir=/data/data/com.termux/files/home/android-sdk
Sesuaikan path dengan lokasi SDK milikmu.

ALTERNATIF BUILD OTOMATIS
Upload seluruh isi project ke repository GitHub. Buka Actions > Build APK. Workflow .github/workflows/build.yml akan membangun APK dan menyimpan artifact FRX-TOOLS-APK.
