package com.faruq.grafik

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.abs

/**
 * Simulasi tampilan grafik (smooth / pixel / retro) dengan scene prosedural bergaya blok.
 * LOD disimulasikan dengan menurunkan resolusi tekstur (faktor = lod + 1).
 */
class PreviewView(ctx: Context) : View(ctx) {

    companion object {
        const val W = 120
        const val H = 60
        private val scene: IntArray by lazy { buildScene() }

        private fun noise(x: Int, y: Int): Int {
            var h = x * 374761393 + y * 668265263
            h = (h xor (h ushr 13)) * 1274126177.toInt()
            return (h xor (h ushr 16)) and 0xff
        }

        private fun shade(c: Int, d: Int) = Color.rgb(
            (Color.red(c) + d).coerceIn(0, 255),
            (Color.green(c) + d).coerceIn(0, 255),
            (Color.blue(c) + d).coerceIn(0, 255)
        )

        private fun buildScene(): IntArray {
            val a = IntArray(W * H)
            for (y in 0 until H) for (x in 0 until W) {
                val nv = noise(x / 2, y / 2) % 40 - 20
                var c = Color.rgb(100 + y, 175 + y / 2, 255)
                // matahari
                if (x in 92..103 && y in 6..17)
                    c = if (noise(x / 2, y / 2) % 5 == 0) Color.rgb(255, 232, 130) else Color.rgb(255, 214, 64)
                // awan
                if ((y in 8..11 && x in 20..38) || (y in 5..8 && x in 26..34))
                    c = shade(Color.rgb(245, 248, 255), nv / 4)
                // gunung
                val top = 20 + abs((x % 48) - 24)
                if (y >= top && y < 38) c = shade(Color.rgb(96, 116, 150), nv / 2)
                // pohon
                if (x in 56..59 && y in 24..37)
                    c = shade(Color.rgb(110, 75, 40), if (x == 57) -25 else nv / 2)
                if (x in 48..67 && y in 12..25)
                    c = shade(Color.rgb(50, 140, 50), nv)
                // tanah
                if (y in 38..41) {
                    c = shade(Color.rgb(95, 170, 60), nv)
                    if (y == 38) c = shade(c, 25)
                    if (x in 78..108) c = shade(Color.rgb(60, 120, 225), nv / 2 + if (y == 38) 30 else 0)
                } else if (y in 42..51) {
                    c = shade(Color.rgb(134, 96, 67), nv)
                    if (noise(x, y) > 235) c = shade(c, -45)
                } else if (y >= 52) {
                    c = shade(Color.rgb(125, 125, 125), nv)
                    if (noise(x, y) > 238) c = shade(c, -50)
                }
                // garis tepi blok
                if (y >= 38 && (x % 20 == 0 || y == 52)) c = shade(c, -35)
                a[y * W + x] = c
            }
            return a
        }
    }

    private var mode = "smooth"
    private var lod = 2
    private var bmp: Bitmap? = null
    private val paint = Paint()
    private val line = Paint().apply { color = 0x66000000 }
    private val clip = Path()
    private val dst = RectF()
    private val d = resources.displayMetrics.density

    fun set(mode: String, lod: Int) {
        this.mode = mode; this.lod = lod
        rebuild(); invalidate()
    }

    private fun rebuild() {
        val f = lod + 1
        val w = W / f
        val h = H / f
        val px = IntArray(w * h)
        for (by in 0 until h) for (bx in 0 until w) {
            var r = 0; var g = 0; var b = 0
            for (yy in 0 until f) for (xx in 0 until f) {
                val c = scene[(by * f + yy) * W + (bx * f + xx)]
                r += Color.red(c); g += Color.green(c); b += Color.blue(c)
            }
            val n = f * f
            r /= n; g /= n; b /= n
            if (mode == "retro") {
                r = (((r + 32) / 64) * 64).coerceAtMost(255)
                g = (((g + 32) / 64) * 64).coerceAtMost(255)
                b = (((b + 32) / 64) * 64).coerceAtMost(255)
            }
            px[by * w + bx] = Color.rgb(r, g, b)
        }
        bmp = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        setMeasuredDimension(w, w / 2)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        clip.reset()
        clip.addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), 12 * d, 12 * d, Path.Direction.CW)
        dst.set(0f, 0f, w.toFloat(), h.toFloat())
    }

    override fun onDraw(canvas: Canvas) {
        val b = bmp ?: run { rebuild(); bmp } ?: return
        canvas.clipPath(clip)
        paint.isFilterBitmap = (mode == "smooth")
        canvas.drawBitmap(b, null, dst, paint)
        if (mode == "retro") {
            var y = 0f
            while (y < height) {
                canvas.drawRect(0f, y, width.toFloat(), y + 1.5f * d, line)
                y += 4 * d
            }
        }
    }
}
