package com.faruq.grafik

import kotlin.system.exitProcess

/** Berjalan di proses shell (uid 2000) lewat Shizuku. */
class ShellService : IShellService.Stub() {
    override fun destroy() { exitProcess(0) }

    override fun exec(cmd: String): String = try {
        val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", "$cmd 2>&1"))
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out.trim()
    } catch (e: Exception) {
        "ERR: ${e.message}"
    }
}
