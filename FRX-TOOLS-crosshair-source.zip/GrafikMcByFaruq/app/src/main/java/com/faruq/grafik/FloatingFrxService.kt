package com.faruq.grafik

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.LinearLayout

class FloatingFrxService : Service() {
    private lateinit var wm: WindowManager
    private var cross: CrosshairView? = null
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var panelShown = false
    private var bubbleLp: WindowManager.LayoutParams? = null
    override fun onCreate() {
        super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        cross = CrosshairView()
        val crossLp = WindowManager.LayoutParams(-1,-1,type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.START }
        wm.addView(cross,crossLp)
        bubble = TextView(this).apply {
            text="FRX"; textSize=13f; setTextColor(Color.WHITE); gravity=Gravity.CENTER
            background=GradientDrawable().apply { shape=GradientDrawable.OVAL; setColor(Color.rgb(105,55,230)); setStroke(dp(2),Color.CYAN) }
            setOnTouchListener(object: View.OnTouchListener {
                var sx=0f; var sy=0f; var ox=0; var oy=0; var moved=false
                override fun onTouch(v:View,e:MotionEvent):Boolean {
                    val lp=bubbleLp ?: return false
                    when(e.action) {
                        MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=lp.x; oy=lp.y; moved=false; return true }
                        MotionEvent.ACTION_MOVE -> { val dx=(e.rawX-sx).toInt(); val dy=(e.rawY-sy).toInt(); if(kotlin.math.abs(dx)+kotlin.math.abs(dy)>8)moved=true; lp.x=ox+dx; lp.y=oy+dy; wm.updateViewLayout(bubble,lp); return true }
                        MotionEvent.ACTION_UP -> { if(!moved) togglePanel(); return true }
                    }; return true
                }
            })
        }
        bubbleLp=WindowManager.LayoutParams(dp(52),dp(52),type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.START; x=dp(12); y=dp(180) }
        wm.addView(bubble,bubbleLp)
    }
    private fun togglePanel() {
        if(panelShown){ panel?.let{wm.removeView(it)}; panel=null; panelShown=false; return }
        val p=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(12),dp(14),dp(12))
            background=GradientDrawable().apply { setColor(Color.rgb(20,20,42)); cornerRadius=dp(16).toFloat(); setStroke(dp(1),Color.CYAN) }
            addView(TextView(this@FloatingFrxService).apply { text="FRX • QUICK PANEL"; setTextColor(Color.WHITE); textSize=14f })
            addView(TextView(this@FloatingFrxService).apply { text="Crosshair overlay aktif"; setTextColor(Color.LTGRAY); textSize=11f })
            addView(TextView(this@FloatingFrxService).apply { text="EXIT"; gravity=Gravity.CENTER; setTextColor(Color.WHITE); setPadding(dp(8),dp(14),dp(8),dp(8)); setOnClickListener{stopSelf()} })
        }
        val lp=WindowManager.LayoutParams(dp(220),-2,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.END; x=dp(12); y=dp(100) }
        wm.addView(p,lp); panel=p; panelShown=true
    }
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    inner class CrosshairView:View(this@FloatingFrxService) {
        private val paint=Paint(3)
        override fun onDraw(c:Canvas){ super.onDraw(c); val p=getSharedPreferences("frx_overlay",MODE_PRIVATE)
            val color=p.getInt("color",Color.GREEN); val size=p.getInt("size",24).toFloat()*resources.displayMetrics.density
            val shape=p.getString("shape","plus")?:"plus"; val cx=width/2f+p.getInt("offset_x",0)*resources.displayMetrics.density; val cy=height/2f+p.getInt("offset_y",0)*resources.displayMetrics.density
            paint.color=color; paint.style=Paint.Style.STROKE; paint.strokeWidth=2.5f*resources.displayMetrics.density
            when(shape){"circle"->c.drawCircle(cx,cy,size,paint);"dot"->{paint.style=Paint.Style.FILL;c.drawCircle(cx,cy,maxOf(2f,size/5),paint)};"square"->c.drawRect(cx-size,cy-size,cx+size,cy+size,paint);else->{c.drawLine(cx-size,cy,cx+size,cy,paint);c.drawLine(cx,cy-size,cx,cy+size,paint)}}
            paint.style=Paint.Style.STROKE; paint.color=Color.WHITE; paint.strokeWidth=1f*resources.displayMetrics.density; c.drawCircle(cx,cy,3f*resources.displayMetrics.density,paint)
        }
    }
    override fun onDestroy(){ getSharedPreferences("frx_overlay",MODE_PRIVATE).edit().putBoolean("enabled",false).apply(); try{panel?.let{wm.removeView(it)};bubble?.let{wm.removeView(it)};cross?.let{wm.removeView(it)}}catch(_:Exception){}; super.onDestroy() }
    override fun onBind(intent:Intent?):IBinder?=null
}
