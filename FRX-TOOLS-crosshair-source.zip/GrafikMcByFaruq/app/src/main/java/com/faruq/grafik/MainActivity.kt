package com.faruq.grafik

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.provider.Settings
import android.os.Bundle
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    companion object {
        const val DEV = "FaruqExe"
        const val TIKTOK = "https://tiktok.com/@faruqexe"
        const val WA = "https://whatsapp.com/channel/0029VbDuMJcBadmisROLuF18"
        val BG = Color.parseColor("#0A0A14")
        val CARD = Color.parseColor("#14142A")
        val CHIP = Color.parseColor("#1C1C38")
        val BORDER = Color.parseColor("#2A2A4D")
        val PURPLE = Color.parseColor("#7C4DFF")
        val CYAN = Color.parseColor("#00E5FF")
        val TXT = Color.parseColor("#F2F2FA")
        val MUTED = Color.parseColor("#9A9AB8")
        val GREEN = Color.parseColor("#2BE38B")
        val RED = Color.parseColor("#FF5C7A")
    }

    private var svc: IShellService? = null
    private lateinit var logView: TextView
    private lateinit var statusText: TextView
    private lateinit var statusDot: View
    private lateinit var gameChips: Chips
    private lateinit var presetChips: Chips
    private lateinit var lodChips: Chips

    // ---------- Shizuku ----------
    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            svc = IShellService.Stub.asInterface(b)
            runOnUiThread { setStatus("Shizuku terhubung", true); logView.text = "Siap dipakai." }
        }
        override fun onServiceDisconnected(n: ComponentName?) {
            svc = null
            runOnUiThread { setStatus("Shizuku terputus", false) }
        }
    }

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName(packageName, ShellService::class.java.name))
            .daemon(false).processNameSuffix("shell").debuggable(false).version(1)
    }

    private val binderL = Shizuku.OnBinderReceivedListener { ensureShizuku() }
    private val permL = Shizuku.OnRequestPermissionResultListener { _, r ->
        if (r == PackageManager.PERMISSION_GRANTED) bind()
        else runOnUiThread { setStatus("Izin Shizuku ditolak", false) }
    }

    private fun ensureShizuku() = runOnUiThread {
        if (!Shizuku.pingBinder()) {
            setStatus("Shizuku belum berjalan", false)
            logView.text = "Buka aplikasi Shizuku dan start dulu."
        } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) bind()
        else Shizuku.requestPermission(1)
    }

    private fun bind() { if (svc == null) Shizuku.bindUserService(args, conn) }

    private fun run(block: (Grafik) -> Unit) {
        val s = svc
        if (s == null) { logView.text = "Belum terhubung ke Shizuku."; ensureShizuku(); return }
        logView.text = "Memproses…"
        Thread {
            val sb = StringBuilder()
            val g = Grafik({ s.exec(it) }, getSharedPreferences("faruq", MODE_PRIVATE), { sb.appendLine(it) })
            try { block(g) } catch (e: Exception) { sb.appendLine("ERROR: ${e.message}") }
            runOnUiThread { logView.text = sb.toString().trim() }
        }.start()
    }

    // ---------- UI helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int, stroke: Int = 0, sw: Int = 1) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(sw), stroke)
    }

    private fun ripple(bg: GradientDrawable) =
        RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), bg, null)

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        typeface = if (bold) Typeface.create("sans-serif-medium", Typeface.BOLD) else Typeface.SANS_SERIF
    }

    private fun lp(w: Int, h: Int, top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top); bottomMargin = dp(bottom) }

    private fun card(title: String?, content: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(CARD, 18, BORDER)
        setPadding(dp(16), dp(14), dp(16), dp(16))
        if (title != null) addView(text(title.uppercase(), 11f, MUTED, true).apply { letterSpacing = 0.12f }, lp(-2, -2, 0, 10))
        addView(content)
    }

    private fun setStatus(t: String, ok: Boolean) {
        statusText.text = t
        statusDot.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (ok) GREEN else RED) }
    }

    private fun openUrl(u: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
        catch (e: Exception) { Toast.makeText(this, "Tidak bisa membuka link", Toast.LENGTH_SHORT).show() }
    }

    private inner class Chips(val opts: List<String>, start: Int) {
        var idx = start
        var onChange: (() -> Unit)? = null
        val value get() = opts[idx]
        val views = mutableListOf<TextView>()
        val row = LinearLayout(this@MainActivity)
        init {
            opts.forEachIndexed { i, o ->
                val tv = text(o, 14f, MUTED, true).apply {
                    gravity = Gravity.CENTER
                    setPadding(dp(4), dp(12), dp(4), dp(12))
                    setOnClickListener { idx = i; refresh(); onChange?.invoke() }
                }
                row.addView(tv, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i > 0) marginStart = dp(8) })
                views.add(tv)
            }
            refresh()
        }
        fun refresh() = views.forEachIndexed { i, tv ->
            if (i == idx) { tv.background = ripple(rounded(PURPLE, 12)); tv.setTextColor(Color.WHITE) }
            else { tv.background = ripple(rounded(CHIP, 12, BORDER)); tv.setTextColor(MUTED) }
        }
    }

    private fun gradientButton(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD); letterSpacing = 0.1f
        setPadding(0, dp(16), 0, dp(16))
        background = ripple(GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(PURPLE, Color.parseColor("#00B8D4")))
            .apply { cornerRadius = dp(14).toFloat() })
        setOnClickListener { onClick() }
    }

    private fun outlineButton(t: String, color: Int, fill: Int, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 13f; setTextColor(color); gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        setPadding(dp(4), dp(14), dp(4), dp(14))
        background = ripple(rounded(fill, 14, color))
        setOnClickListener { onClick() }
    }

    // ---------- Screen ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(24))
        }

        // Header + logo
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ic_logo_fg)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#120A2E"), Color.parseColor("#3B1FB8"), PURPLE))
                .apply { cornerRadius = dp(18).toFloat(); setStroke(dp(1), BORDER) }
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(2), dp(2), dp(2), dp(2))
        }
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(text("FRX TOOLS", 24f, TXT, true).apply { letterSpacing = 0.1f })
            addView(text("Grafik Minecraft • v2.0", 13f, CYAN, true))
            addView(text("by $DEV", 12f, MUTED))
        }
        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(logo, LinearLayout.LayoutParams(dp(68), dp(68)))
            addView(titles, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(14) })
        }
        root.addView(header, lp(-1, -2, 0, 16))

        // Status pill
        statusDot = View(this)
        statusText = text("Menghubungkan ke Shizuku…", 12f, TXT, true)
        val pill = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(CARD, 20, BORDER)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            addView(statusDot, LinearLayout.LayoutParams(dp(8), dp(8)).apply { marginEnd = dp(8) })
            addView(statusText)
        }
        setStatus("Menghubungkan ke Shizuku…", false)
        root.addView(pill, lp(-2, -2, 0, 12))

        // Pickers
        gameChips = Chips(Grafik.GAMES.keys.toList(), 1)
        presetChips = Chips(listOf("smooth", "pixel", "retro"), 0)
        lodChips = Chips(listOf("1", "2", "3", "4"), 1)
        root.addView(card("Game", gameChips.row), lp(-1, -2, 0, 12))
        root.addView(card("Preset grafik", presetChips.row), lp(-1, -2, 0, 12))
        root.addView(card("Level LOD", lodChips.row), lp(-1, -2, 0, 12))

        // Perbandingan grafik (simulasi)
        val presets = listOf("smooth", "pixel", "retro")
        val descs = listOf(
            "Tekstur halus, tepi lembut.",
            "Tekstur kotak-kotak tajam.",
            "Pixel tajam, warna terbatas, garis scanline."
        )
        val prevViews = presets.map { PreviewView(this) }
        val frames = presets.map { LinearLayout(this).apply { setPadding(dp(3), dp(3), dp(3), dp(3)) } }
        val cmp = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val refreshPreview = {
            val l = lodChips.value.toInt()
            prevViews.forEachIndexed { i, pv ->
                pv.set(presets[i], l)
                frames[i].background =
                    if (i == presetChips.idx) rounded(Color.TRANSPARENT, 15, PURPLE, 2)
                    else rounded(Color.TRANSPARENT, 15, BORDER)
            }
        }
        presets.forEachIndexed { i, p ->
            frames[i].addView(prevViews[i], LinearLayout.LayoutParams(-1, -2))
            frames[i].setOnClickListener { presetChips.idx = i; presetChips.refresh(); refreshPreview() }
            cmp.addView(frames[i], lp(-1, -2, if (i == 0) 0 else 12, 6))
            cmp.addView(LinearLayout(this).apply {
                addView(text(p.uppercase(), 12f, TXT, true).apply { letterSpacing = 0.1f })
                addView(text("  •  ${descs[i]}", 12f, MUTED))
            })
        }
        cmp.addView(text("Simulasi ilustrasi. Hasil asli di game bisa beda tergantung ROM dan game. Tap gambar untuk memilih preset.", 11f, MUTED), lp(-1, -2, 12, 0))
        presetChips.onChange = refreshPreview
        lodChips.onChange = refreshPreview
        refreshPreview()
        root.addView(card("Perbandingan grafik", cmp), lp(-1, -2, 0, 16))

        // Actions
        val game = { gameChips.value }
        root.addView(gradientButton("TERAPKAN GRAFIK") {
            val p = presetChips.value; val l = lodChips.value.toInt()
            run { it.apply(game(), p, l) }
        }, lp(-1, -2, 0, 10))

        val row = LinearLayout(this)
        fun add(v: View, first: Boolean) =
            row.addView(v, LinearLayout.LayoutParams(0, -2, 1f).apply { if (!first) marginStart = dp(8) })
        add(outlineButton("CEK", CYAN, CHIP) { run { it.checkDevice() } }, true)
        add(outlineButton("OFF", RED, CHIP) { run { it.off(game()) } }, false)
        add(outlineButton("STATUS", GREEN, CHIP) { run { it.status(game()) } }, false)
        root.addView(row, lp(-1, -2, 0, 16))

        // FRX crosshair and floating overlay controls
        val overlayPrefs = getSharedPreferences("frx_overlay", MODE_PRIVATE)
        val overlayCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val overlaySwitch = Switch(this).apply {
            text = "FLOATING FRX + CROSSHAIR"
            setTextColor(TXT); textSize = 14f
            isChecked = overlayPrefs.getBoolean("enabled", false)
        }
        fun startOverlay(enabled: Boolean) {
            if (enabled && !Settings.canDrawOverlays(this)) {
                overlaySwitch.isChecked = false
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                Toast.makeText(this, "Izinkan tampil di atas aplikasi, lalu aktifkan lagi.", Toast.LENGTH_LONG).show()
                return
            }
            overlayPrefs.edit().putBoolean("enabled", enabled).apply()
            val i = Intent(this, FloatingFrxService::class.java)
            if (enabled) startService(i) else stopService(i)
        }
        overlaySwitch.setOnCheckedChangeListener { _, checked -> startOverlay(checked) }
        overlayCard.addView(overlaySwitch, lp(-1, -2, 0, 8))

        val shapeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("plus", "circle", "dot", "square"))
            setSelection(listOf("plus", "circle", "dot", "square").indexOf(overlayPrefs.getString("shape", "plus")).coerceAtLeast(0))
        }
        overlayCard.addView(text("Bentuk crosshair", 12f, MUTED, true), lp(-1, -2, 0, 3))
        overlayCard.addView(shapeSpinner, lp(-1, -2, 0, 6))
        val colorSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Hijau", "Merah", "Cyan", "Kuning", "Putih", "Ungu"))
            val colors = listOf(Color.GREEN, Color.RED, CYAN, Color.YELLOW, Color.WHITE, PURPLE)
            setSelection(colors.indexOf(overlayPrefs.getInt("color", Color.GREEN)).coerceAtLeast(0))
        }
        overlayCard.addView(text("Warna", 12f, MUTED, true), lp(-1, -2, 0, 3))
        overlayCard.addView(colorSpinner, lp(-1, -2, 0, 6))
        fun addSeek(label: String, key: String, max: Int, initial: Int) {
            overlayCard.addView(text(label, 12f, MUTED, true), lp(-1, -2, 0, 2))
            val seek = SeekBar(this).apply { this.max = max; progress = overlayPrefs.getInt(key, initial) }
            overlayCard.addView(seek, lp(-1, -2, 0, 4))
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(b: SeekBar?, value: Int, fromUser: Boolean) { overlayPrefs.edit().putInt(key, if (key.startsWith("offset")) value - max/2 else value).apply() }
                override fun onStartTrackingTouch(b: SeekBar?) {}
                override fun onStopTrackingTouch(b: SeekBar?) { if (overlayPrefs.getBoolean("enabled", false)) { stopService(Intent(this@MainActivity, FloatingFrxService::class.java)); startService(Intent(this@MainActivity, FloatingFrxService::class.java)) } }
            })
        }
        addSeek("Ukuran crosshair", "size", 80, 24)
        addSeek("Posisi horizontal (geser dari tengah)", "offset_x", 201, 100)
        addSeek("Posisi vertikal (geser dari tengah)", "offset_y", 201, 100)
        val saveOverlay = outlineButton("SIMPAN & TERAPKAN CROSSHAIR", CYAN, CHIP) {
            val colors = listOf(Color.GREEN, Color.RED, CYAN, Color.YELLOW, Color.WHITE, PURPLE)
            overlayPrefs.edit().putString("shape", shapeSpinner.selectedItem.toString()).putInt("color", colors[colorSpinner.selectedItemPosition]).apply()
            if (overlayPrefs.getBoolean("enabled", false)) { stopService(Intent(this, FloatingFrxService::class.java)); startService(Intent(this, FloatingFrxService::class.java)) }
            Toast.makeText(this, "Pengaturan crosshair disimpan", Toast.LENGTH_SHORT).show()
        }
        overlayCard.addView(saveOverlay, lp(-1, -2, 0, 4))
        root.addView(card("Crosshair & Floating FRX", overlayCard), lp(-1, -2, 0, 14))

        // Clear only this app's cache; Android does not allow a normal app to clear other apps' cache.
        root.addView(outlineButton("BERSIHKAN CACHE FRX-TOOLS", GREEN, CHIP) {
            val ok = try { cacheDir.listFiles()?.forEach { f -> f.deleteRecursively() }; true } catch (_: Exception) { false }
            Toast.makeText(this, if (ok) "Cache FRX-TOOLS dibersihkan" else "Cache gagal dibersihkan", Toast.LENGTH_LONG).show()
        }, lp(-1, -2, 0, 10))

        // Log terminal
        logView = text("Menunggu perintah…", 12f, GREEN).apply {
            typeface = Typeface.MONOSPACE; setTextIsSelectable(true); setLineSpacing(0f, 1.25f)
        }
        val term = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.parseColor("#05050C"), 16, BORDER)
            setPadding(dp(14), dp(12), dp(14), dp(14))
            addView(text("LOG", 11f, MUTED, true).apply { letterSpacing = 0.12f }, lp(-2, -2, 0, 6))
            addView(logView, ViewGroup.LayoutParams(-1, -2))
        }
        root.addView(term, lp(-1, -2, 0, 20))

        // Developer + social
        val social = LinearLayout(this)
        social.addView(outlineButton("TikTok", Color.parseColor("#FE2C55"), Color.parseColor("#1A0A12")) { openUrl(TIKTOK) },
            LinearLayout.LayoutParams(0, -2, 1f))
        social.addView(outlineButton("Saluran WhatsApp", Color.parseColor("#25D366"), Color.parseColor("#0A1A12")) { openUrl(WA) },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
        val dev = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(text("DEVELOPER", 11f, MUTED, true).apply { letterSpacing = 0.12f })
            addView(text(DEV, 20f, TXT, true), lp(-2, -2, 2, 12))
            addView(social)
        }
        root.addView(card(null, dev), lp(-1, -2, 0, 14))
        root.addView(text("© FRX TOOLS • $DEV", 11f, MUTED).apply { gravity = Gravity.CENTER }, lp(-1, -2))

        setContentView(ScrollView(this).apply { setBackgroundColor(BG); isFillViewport = true; addView(root) })

        Shizuku.addBinderReceivedListenerSticky(binderL)
        Shizuku.addRequestPermissionResultListener(permL)
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeBinderReceivedListener(binderL)
        Shizuku.removeRequestPermissionResultListener(permL)
        if (svc != null) try { Shizuku.unbindUserService(args, conn, true) } catch (_: Exception) {}
    }
}
