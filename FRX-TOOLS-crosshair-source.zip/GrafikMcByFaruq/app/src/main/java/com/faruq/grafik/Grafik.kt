package com.faruq.grafik

import android.content.SharedPreferences
import android.os.Build

/** Port dari script GrafikMcByFaruq.sh v2.0 */
class Grafik(
    private val sh: (String) -> String,
    private val prefs: SharedPreferences,
    private val out: (String) -> Unit
) {
    companion object {
        const val PKGS = "angle_gl_driver_selection_pkgs"
        const val VALS = "angle_gl_driver_selection_values"
        const val FEAT = "debug.angle.feature_overrides_enabled"
        const val PROBE = "faruq_angle_support_probe"
        val GAMES = mapOf(
            "Free Fire biasa" to "com.dts.freefireth",
            "Free Fire MAX" to "com.dts.freefiremax"
        )
    }

    private fun gget(k: String) = sh("settings get global $k")
    private fun prop(k: String) = sh("getprop $k")
    private fun ok(m: String) = out("[✓] $m")
    private fun warn(m: String) = out("[!] $m")
    private fun fail(m: String) = out("[✗] $m")

    fun checkDevice(): Boolean {
        var pass = true
        out("== INFO PERANGKAT ==")
        out("Brand   : ${prop("ro.product.manufacturer")}")
        out("Model   : ${prop("ro.product.model")}")
        out("Android : ${prop("ro.build.version.release")}")
        out("SDK     : ${Build.VERSION.SDK_INT}")
        out("Shell ID: ${sh("id")}")
        out("\n== CEK KOMPATIBILITAS ==")
        if (Build.VERSION.SDK_INT >= 29) ok("Android 10+ (syarat dasar ANGLE).")
        else { fail("Android di bawah 10."); pass = false }

        for (c in listOf("settings", "getprop", "setprop", "pm")) {
            if (sh("command -v $c").isNotEmpty()) ok("Perintah $c tersedia.")
            else { fail("Perintah $c tidak ditemukan."); pass = false }
        }

        // tes tulis/baca/hapus dengan key khusus
        val old = gget(PROBE)
        sh("settings put global $PROBE faruq_test")
        if (gget(PROBE) == "faruq_test") ok("Akses tulis Settings Global tersedia.")
        else { fail("Akses tulis Settings Global ditolak."); pass = false }
        if (old.isNotEmpty() && old != "null") sh("settings put global $PROBE '$old'")
        else sh("settings delete global $PROBE")

        out("")
        if (pass) {
            out("DEVICE LOLOS PEMERIKSAAN DASAR")
            warn("Belum menjamin ANGLE/efek grafis didukung ROM atau game.")
        } else out("DEVICE BELUM LOLOS PEMERIKSAAN")
        return pass
    }

    private fun saveBackup() {
        if (!prefs.getBoolean("has_backup", false)) {
            prefs.edit()
                .putString("old_pkgs", gget(PKGS))
                .putString("old_values", gget(VALS))
                .putString("old_feature", prop(FEAT))
                .putBoolean("has_backup", true).apply()
        }
    }

    private fun restore(key: String, v: String?) {
        if (v.isNullOrEmpty() || v == "null") sh("settings delete global $key")
        else sh("settings put global $key '$v'")
    }

    private fun report(game: String, pkg: String, preset: String, lod: String, status: String) {
        out("\n== HASIL KONFIGURASI ==")
        out("Game    : $game")
        out("Package : $pkg")
        out("Preset  : $preset")
        out("LOD     : $lod")
        out("Status  : $status")
        out("ANGLE list : ${gget(PKGS)}")
        out("ANGLE mode : ${gget(VALS)}")
        out("Feature    : ${prop(FEAT)}")
        warn("Status aktif = nilai terbaca kembali, bukan bukti FPS naik.")
    }

    fun apply(game: String, preset: String, lod: Int) {
        val pkg = GAMES[game] ?: return fail("Game tidak dikenal.")
        val feature = when (preset) {
            "smooth" -> "disableAnisotropicFiltering:forceTextureLodOffset$lod"
            "pixel", "retro" ->
                "forceNearestFiltering:disableAnisotropicFiltering:forceTextureLodOffset$lod"
            else -> return fail("Preset tidak dikenal.")
        }
        if (lod !in 1..4) return fail("LOD harus 1-4.")
        if (!checkDevice()) return fail("Pemeriksaan perangkat gagal.")
        if (!sh("pm path $pkg").startsWith("package:")) {
            fail("$game tidak terdeteksi. Cek game terpasang / package clone berbeda.")
            return
        }
        saveBackup()
        sh("settings put global $PKGS $pkg")
        sh("settings put global $VALS angle")
        sh("setprop $FEAT '$feature'")
        sh("am force-stop $pkg")

        if (gget(PKGS) == pkg && gget(VALS) == "angle") {
            if (prop(FEAT) != feature) warn("Feature override tidak terbaca sama; mungkin dibatasi ROM.")
            report(game, pkg, preset, lod.toString(), "KONFIGURASI TERSIMPAN")
            out("\nBuka kembali game secara manual.")
        } else report(game, pkg, preset, lod.toString(), "GAGAL / TIDAK TERSIMPAN")
    }

    fun off(game: String) {
        val pkg = GAMES[game] ?: return fail("Game tidak dikenal.")
        val status: String
        if (prefs.getBoolean("has_backup", false)) {
            restore(PKGS, prefs.getString("old_pkgs", null))
            restore(VALS, prefs.getString("old_values", null))
            val f = prefs.getString("old_feature", "") ?: ""
            sh("setprop $FEAT '${if (f == "null") "" else f}'")
            prefs.edit().putBoolean("has_backup", false).apply()
            status = "PENGATURAN SEBELUMNYA DIPULIHKAN"
        } else {
            sh("settings delete global $PKGS")
            sh("settings delete global $VALS")
            sh("setprop $FEAT ''")
            status = "PENGATURAN ANGLE DIHAPUS (TANPA BACKUP)"
        }
        sh("am force-stop $pkg")
        report(game, pkg, "Default / Off", "-", status)
        out("\nBuka kembali game secara manual.")
    }

    fun status(game: String) {
        val pkg = GAMES[game] ?: return fail("Game tidak dikenal.")
        val s = if (gget(PKGS) == pkg) "PACKAGE TERPILIH DI SETTINGS" else "PACKAGE TIDAK TERPILIH"
        report(game, pkg, "Status saat ini", "-", s)
    }
}
