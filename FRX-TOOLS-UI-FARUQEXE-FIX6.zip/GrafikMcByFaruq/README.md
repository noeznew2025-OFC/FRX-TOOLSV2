# FRX TOOLS • FaruqExe

## Floating crosshair
- Mengaktifkan Floating Menu tidak otomatis menampilkan crosshair.
- Buka tile CROSSHAIR untuk membuka panel kontrol terpisah.
- Tekan tombol OFF/ON di panel CROSSHAIR CONTROL untuk mengaktifkan atau mematikan crosshair.
- Saat Floating Service dimulai ulang, crosshair kembali dalam keadaan OFF.

Modul shell `GrafikMcByFaruq.sh` tetap disertakan.
