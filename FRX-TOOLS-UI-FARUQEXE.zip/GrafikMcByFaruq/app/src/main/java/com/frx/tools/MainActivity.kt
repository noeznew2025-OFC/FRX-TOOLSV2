package com.frx.tools

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    companion object { const val ACTION_SCREENSHOT = "com.frx.tools.REQUEST_SCREENSHOT" }
    private lateinit var logView: TextView
    private val screenshotRequest = 710
    private var selectedGame = "ff"
    private var selectedPreset = "smooth"
    private var selectedLod = 2
    private val handler = Handler(Looper.getMainLooper())
    private val bg = Color.rgb(8, 11, 18)
    private val panel = Color.rgb(17, 23, 34)
    private val red = Color.rgb(255, 55, 69)
    private val muted = Color.rgb(160, 172, 190)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        if (intent?.action == ACTION_SCREENSHOT) handler.postDelayed({ requestScreenshot() }, 350)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(26))
            setBackgroundColor(bg)
        }

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(18))
            background = gradient(intArrayOf(Color.rgb(25, 34, 50), Color.rgb(12, 16, 25)), dp(20))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.frx_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        hero.addView(logo, LinearLayout.LayoutParams(dp(76), dp(76)))
        val brandText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0) }
        brandText.addView(label("FRX TOOLS", 27f, Color.WHITE, true))
        brandText.addView(label("GAMING GRAPHICS CONTROL", 10f, red, true).apply { letterSpacing = 0.12f })
        brandText.addView(label("DEVELOPER  •  FaruqExe", 11f, muted, false).apply { setPadding(0, dp(7), 0, 0) })
        hero.addView(brandText, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(hero)

        val socialRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(5)) }
        socialRow.addView(actionButton("TikTok  ↗", false) { openLink("https://tiktok.com/@faruqexe") }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { rightMargin = dp(6) })
        socialRow.addView(actionButton("WhatsApp Channel  ↗", false) { openLink("https://whatsapp.com/channel/0029VbDuMJcBadmisROLuF18") }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { leftMargin = dp(6) })
        root.addView(socialRow)

        sectionTitle(root, "VISUAL PRESET GUIDE", "Contoh ilustrasi karakter tampilan setiap preset")
        val compareScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val compareRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        compareRow.addView(previewCard("PIXEL", "Tepi tegas • blok piksel", "pixel"))
        compareRow.addView(previewCard("SMOOTH", "Gradasi • transisi halus", "smooth"))
        compareRow.addView(previewCard("RETRO", "Nuansa klasik • scanline", "retro"))
        compareScroll.addView(compareRow)
        root.addView(compareScroll)
        root.addView(label("Preview ini ilustrasi perbedaan gaya, bukan screenshot hasil game. Hasil aktual bergantung pada perangkat dan dukungan ANGLE.", 10f, muted, false).apply { setPadding(dp(2), dp(8), dp(2), dp(4) })

        sectionTitle(root, "CONTROL CENTER", "Pilih game dan atur konfigurasi grafis")
        val gameCard = card()
        gameCard.addView(label("TARGET GAME", 11f, red, true))
        val gameRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        gameRow.addView(actionButton("FREE FIRE", selectedGame == "ff") { selectedGame = "ff"; toast("Target: Free Fire"); buildUi() }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { rightMargin = dp(5) })
        gameRow.addView(actionButton("FREE FIRE MAX", selectedGame == "max") { selectedGame = "max"; toast("Target: Free Fire MAX"); buildUi() }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { leftMargin = dp(5) })
        gameCard.addView(gameRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        root.addView(gameCard)

        val presetCard = card()
        presetCard.addView(label("PILIH PRESET", 11f, red, true))
        val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("smooth" to "SMOOTH", "pixel" to "PIXEL", "retro" to "RETRO").forEach { (key, title) ->
            presetRow.addView(actionButton(title, selectedPreset == key) { selectedPreset = key; toast("Preset $title dipilih"); buildUi() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { if (key != "smooth") leftMargin = dp(4); if (key != "retro") rightMargin = dp(4) })
        }
        presetCard.addView(presetRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        val lodLabel = label("LEVEL OF DETAIL (LOD): $selectedLod", 12f, Color.WHITE, true).apply { setPadding(0, dp(14), 0, 0) }
        presetCard.addView(lodLabel)
        presetCard.addView(SeekBar(this).apply {
            max = 3; progress = selectedLod - 1
            progressTintList = android.content.res.ColorStateList.valueOf(red)
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { selectedLod = progress + 1; lodLabel.text = "LEVEL OF DETAIL (LOD): $selectedLod" }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        })
        root.addView(presetCard)

        sectionTitle(root, "ACTIONS", "Terapkan, periksa, atau pulihkan konfigurasi")
        val actions = card()
        actions.addView(actionButton("CEK KOMPATIBILITAS PERANGKAT", false) { runModule("check") })
        actions.addView(actionButton("TERAPKAN KONFIGURASI ANGLE", true) { runModule("$selectedGame on $selectedPreset $selectedLod") })
        val restoreRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        restoreRow.addView(actionButton("PULIHKAN FF", false) { runModule("ff off") }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { rightMargin = dp(5) })
        restoreRow.addView(actionButton("PULIHKAN MAX", false) { runModule("max off") }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(5) })
        actions.addView(restoreRow)
        val statusRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        statusRow.addView(actionButton("STATUS FF", false) { runModule("ff status") }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { rightMargin = dp(5) })
        statusRow.addView(actionButton("STATUS MAX", false) { runModule("max status") }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(5) })
        actions.addView(statusRow)
        actions.addView(actionButton("CLEAR CACHE SISTEM", false) {
            runPrivileged("pm trim-caches 1G", "Permintaan pembersihan cache dikirim ke Android. Hasil bergantung pada kebijakan sistem.")
        })
        actions.addView(actionButton("SCREENSHOT LAYAR", false) { requestScreenshot() })
        root.addView(actions)

        sectionTitle(root, "FLOATING TOOLS", "Crosshair dan menu pintasan di atas aplikasi")
        val floating = card()
        floating.addView(actionButton("AKTIFKAN FLOATING FRX", true) {
            if (!android.provider.Settings.canDrawOverlays(this)) {
                startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName")))
                toast("Izinkan tampil di atas aplikasi lain, lalu tekan tombol lagi.")
            } else {
                startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACTION_START))
                toast("Floating FRX diaktifkan")
            }
        })
        floating.addView(actionButton("MATIKAN FLOATING FRX", false) { startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACTION_STOP)) })
        root.addView(floating)

        logView = TextView(this).apply {
            text = "STATUS: Siap. Hubungkan Shizuku untuk fungsi modul ANGLE dan pembersihan cache."
            textSize = 11f; setTextColor(Color.rgb(218, 226, 238)); setPadding(dp(14), dp(14), dp(14), dp(14))
            background = gradient(intArrayOf(Color.rgb(19, 27, 40), Color.rgb(13, 18, 28)), dp(14))
        }
        root.addView(logView, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        root.addView(label("FRX TOOLS  •  DEVELOPER FaruqExe", 10f, muted, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(18), 0, 0) })

        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
    }

    private fun previewCard(title: String, subtitle: String, mode: String): View {
        val c = card().apply {
            setPadding(dp(10), dp(10), dp(10), dp(10))
            layoutParams = LinearLayout.LayoutParams(dp(176), -2).apply { rightMargin = dp(9) }
        }
        c.addView(GraphicPreview(this, mode), LinearLayout.LayoutParams(dp(154), dp(102)))
        c.addView(label(title, 13f, Color.WHITE, true).apply { setPadding(0, dp(9), 0, dp(2)) })
        c.addView(label(subtitle, 10f, muted, false))
        c.addView(actionButton("PILIH $title", selectedPreset == mode) { selectedPreset = mode; toast("Preset $title dipilih"); buildUi() }, LinearLayout.LayoutParams(-1, dp(38)).apply { topMargin = dp(8) })
        return c
    }

    private fun sectionTitle(parent: LinearLayout, title: String, subtitle: String) {
        parent.addView(label(title, 13f, red, true).apply { setPadding(dp(2), dp(20), 0, dp(3)); letterSpacing = 0.08f })
        parent.addView(label(subtitle, 10f, muted, false).apply { setPadding(dp(2), 0, 0, dp(9)) })
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = gradient(intArrayOf(panel, Color.rgb(13, 18, 28)), dp(17))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) }
    }

    private fun label(textValue: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = textValue; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    private fun actionButton(textValue: String, active: Boolean, action: () -> Unit): Button = Button(this).apply {
        text = textValue; isAllCaps = false; textSize = 11f; minHeight = 0; minimumHeight = 0
        setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif", Typeface.BOLD)
        background = gradient(if (active) intArrayOf(Color.rgb(255, 65, 78), Color.rgb(178, 28, 45)) else intArrayOf(Color.rgb(38, 49, 66), Color.rgb(25, 34, 48)), dp(11))
        stateListAnimator = null
        setOnClickListener { action() }
    }

    private fun gradient(colors: IntArray, radius: Int): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply { cornerRadius = radius.toFloat() }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun openLink(url: String) { try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))) } catch (_: Exception) { toast("Tidak ada aplikasi untuk membuka tautan.") } }

    private fun runModule(args: String) {
        try {
            if (!Shizuku.pingBinder()) { showLog("Shizuku belum aktif. Jalankan aplikasi Shizuku dan hubungkan layanan terlebih dahulu."); return }
            if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) { Shizuku.requestPermission(501); showLog("Menunggu izin Shizuku. Setelah diizinkan, tekan tombol lagi."); return }
            Thread {
                try {
                    val command = arrayOf("sh", "-s", "--") + args.trim().split(Regex("\\s+")).toTypedArray()
                    val process = Shizuku.newProcess(command, null, null)
                    assets.open("GrafikMcByFaruq.sh").bufferedReader().use { script -> process.outputStream.bufferedWriter().use { input -> input.write(script.readText()) } }
                    val output = process.inputStream.bufferedReader().readText(); val error = process.errorStream.bufferedReader().readText(); val code = process.waitFor()
                    runOnUiThread { showLog("Menjalankan modul: $args\nExit: $code\n$output\n$error".trim()) }
                } catch (e: Exception) { runOnUiThread { showLog("Gagal menjalankan modul: ${e.message}") } }
            }.start()
        } catch (e: Exception) { showLog("Shizuku error: ${e.message}") }
    }

    private fun runPrivileged(command: String, successText: String) {
        try {
            if (!Shizuku.pingBinder()) { showLog("Shizuku belum aktif. Jalankan aplikasi Shizuku dan hubungkan layanan terlebih dahulu."); return }
            if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) { Shizuku.requestPermission(501); showLog("Menunggu izin Shizuku. Setelah diizinkan, tekan tombol lagi."); return }
            Thread {
                try {
                    val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
                    val output = process.inputStream.bufferedReader().readText(); val error = process.errorStream.bufferedReader().readText(); val code = process.waitFor()
                    runOnUiThread { showLog("$successText\nExit: $code\n$output\n$error".trim()) }
                } catch (e: Exception) { runOnUiThread { showLog("Gagal menjalankan perintah: ${e.message}") } }
            }.start()
        } catch (e: Exception) { showLog("Shizuku error: ${e.message}") }
    }

    private fun requestScreenshot() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), screenshotRequest)
    }

    @Deprecated("MediaProjection consent callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != screenshotRequest) return
        if (resultCode != RESULT_OK || data == null) { toast("Screenshot dibatalkan."); return }
        val serviceIntent = Intent(this, CaptureService::class.java).apply { putExtra(CaptureService.EXTRA_RESULT, resultCode); putExtra(CaptureService.EXTRA_DATA, data) }
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
        toast("Permintaan screenshot diterima. Hasil masuk Pictures/FRX TOOLS.")
    }

    private fun showLog(message: String) { logView.text = message }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private inner class GraphicPreview(context: Context, private val mode: String) : View(context) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            val colors = when (mode) {
                "pixel" -> intArrayOf(Color.rgb(23, 39, 62), Color.rgb(52, 79, 103))
                "retro" -> intArrayOf(Color.rgb(48, 35, 59), Color.rgb(118, 63, 68))
                else -> intArrayOf(Color.rgb(16, 55, 67), Color.rgb(67, 126, 132))
            }
            p.shader = LinearGradient(0f, 0f, 0f, h, colors[0], colors[1], Shader.TileMode.CLAMP)
            canvas.drawRoundRect(0f, 0f, w, h, dp(10).toFloat(), dp(10).toFloat(), p)
            p.shader = null
            // Stylized hills / terrain, intentionally illustrative rather than a game screenshot.
            p.color = when (mode) { "pixel" -> Color.rgb(56, 107, 91); "retro" -> Color.rgb(180, 111, 76); else -> Color.rgb(65, 151, 126) }
            if (mode == "pixel") {
                val block = w / 12f
                for (i in 0..11) {
                    val top = h * (0.48f + ((i * 7) % 4) * 0.045f)
                    canvas.drawRect(i * block, top, (i + 1) * block + 1, h, p)
                }
                p.color = Color.rgb(214, 185, 116)
                canvas.drawRect(w * .12f, h * .33f, w * .32f, h * .48f, p)
                canvas.drawRect(w * .69f, h * .25f, w * .88f, h * .47f, p)
            } else {
                val path = Path().apply { moveTo(0f, h * .66f); cubicTo(w * .25f, h * .37f, w * .47f, h * .83f, w, h * .48f); lineTo(w, h); lineTo(0f, h); close() }
                canvas.drawPath(path, p)
                p.color = if (mode == "retro") Color.rgb(228, 169, 103) else Color.rgb(122, 196, 151)
                canvas.drawCircle(w * .76f, h * .25f, h * .105f, p)
                p.color = Color.argb(110, 8, 15, 24)
                canvas.drawOval(w * .12f, h * .67f, w * .48f, h * .83f, p)
            }
            if (mode == "retro") {
                p.color = Color.argb(38, 255, 232, 190); p.strokeWidth = 1f
                var y = 3f; while (y < h) { canvas.drawLine(0f, y, w, y, p); y += 4f }
                p.color = Color.rgb(255, 210, 144); p.style = Paint.Style.STROKE; p.strokeWidth = dp(1).toFloat()
                canvas.drawRoundRect(4f, 4f, w - 4f, h - 4f, dp(7).toFloat(), dp(7).toFloat(), p); p.style = Paint.Style.FILL
            }
            if (mode == "smooth") {
                p.color = Color.argb(45, 255, 255, 255)
                canvas.drawRoundRect(w * .08f, h * .08f, w * .92f, h * .18f, h * .05f, h * .05f, p)
            }
        }
    }
}
